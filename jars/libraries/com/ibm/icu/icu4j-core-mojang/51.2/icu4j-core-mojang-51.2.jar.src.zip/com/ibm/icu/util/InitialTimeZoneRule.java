package com.ibm.icu.util;

import java.util.Date;

public class InitialTimeZoneRule extends TimeZoneRule {
  private static final long serialVersionUID = 1876594993064051206L;
  
  public InitialTimeZoneRule(String name, int rawOffset, int dstSavings) {
    super(name, rawOffset, dstSavings);
  }
  
  public boolean isEquivalentTo(TimeZoneRule other) {
    if (other instanceof InitialTimeZoneRule)
      return super.isEquivalentTo(other); 
    return false;
  }
  
  public Date getFinalStart(int prevRawOffset, int prevDSTSavings) {
    return null;
  }
  
  public Date getFirstStart(int prevRawOffset, int prevDSTSavings) {
    return null;
  }
  
  public Date getNextStart(long base, int prevRawOffset, int prevDSTSavings, boolean inclusive) {
    return null;
  }
  
  public Date getPreviousStart(long base, int prevRawOffset, int prevDSTSavings, boolean inclusive) {
    return null;
  }
  
  public boolean isTransitionRule() {
    return false;
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\ibm\icu\icu4j-core-mojang\51.2\icu4j-core-mojang-51.2.jar!\com\ibm\ic\\util\InitialTimeZoneRule.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */