package com.ibm.icu.text;

public interface UnicodeMatcher {
  public static final int U_MISMATCH = 0;
  
  public static final int U_PARTIAL_MATCH = 1;
  
  public static final int U_MATCH = 2;
  
  public static final char ETHER = '￿';
  
  int matches(Replaceable paramReplaceable, int[] paramArrayOfint, int paramInt, boolean paramBoolean);
  
  String toPattern(boolean paramBoolean);
  
  boolean matchesIndexValue(int paramInt);
  
  void addMatchSetTo(UnicodeSet paramUnicodeSet);
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\ibm\icu\icu4j-core-mojang\51.2\icu4j-core-mojang-51.2.jar!\com\ibm\icu\text\UnicodeMatcher.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */