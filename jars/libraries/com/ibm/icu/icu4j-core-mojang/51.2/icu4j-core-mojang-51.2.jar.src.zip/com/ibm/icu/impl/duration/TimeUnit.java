package com.ibm.icu.impl.duration;

public final class TimeUnit {
  final String name;
  
  final byte ordinal;
  
  private TimeUnit(String name, int ordinal) {
    this.name = name;
    this.ordinal = (byte)ordinal;
  }
  
  public String toString() {
    return this.name;
  }
  
  public static final TimeUnit YEAR = new TimeUnit("year", 0);
  
  public static final TimeUnit MONTH = new TimeUnit("month", 1);
  
  public static final TimeUnit WEEK = new TimeUnit("week", 2);
  
  public static final TimeUnit DAY = new TimeUnit("day", 3);
  
  public static final TimeUnit HOUR = new TimeUnit("hour", 4);
  
  public static final TimeUnit MINUTE = new TimeUnit("minute", 5);
  
  public static final TimeUnit SECOND = new TimeUnit("second", 6);
  
  public static final TimeUnit MILLISECOND = new TimeUnit("millisecond", 7);
  
  public TimeUnit larger() {
    return (this.ordinal == 0) ? null : units[this.ordinal - 1];
  }
  
  public TimeUnit smaller() {
    return (this.ordinal == units.length - 1) ? null : units[this.ordinal + 1];
  }
  
  static final TimeUnit[] units = new TimeUnit[] { YEAR, MONTH, WEEK, DAY, HOUR, MINUTE, SECOND, MILLISECOND };
  
  public int ordinal() {
    return this.ordinal;
  }
  
  static final long[] approxDurations = new long[] { 31557600000L, 2630880000L, 604800000L, 86400000L, 3600000L, 60000L, 1000L, 1L };
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\ibm\icu\icu4j-core-mojang\51.2\icu4j-core-mojang-51.2.jar!\com\ibm\icu\impl\duration\TimeUnit.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */