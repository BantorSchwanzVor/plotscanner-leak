package com.ibm.icu.util;

public class Output<T> {
  public T value;
  
  public String toString() {
    return (this.value == null) ? "null" : this.value.toString();
  }
  
  public Output() {}
  
  public Output(T value) {
    this.value = value;
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\ibm\icu\icu4j-core-mojang\51.2\icu4j-core-mojang-51.2.jar!\com\ibm\ic\\util\Output.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */