package com.ibm.icu.text;

class AbsoluteValueSubstitution extends NFSubstitution {
  AbsoluteValueSubstitution(int pos, NFRuleSet ruleSet, RuleBasedNumberFormat formatter, String description) {
    super(pos, ruleSet, formatter, description);
  }
  
  public long transformNumber(long number) {
    return Math.abs(number);
  }
  
  public double transformNumber(double number) {
    return Math.abs(number);
  }
  
  public double composeRuleValue(double newRuleValue, double oldRuleValue) {
    return -newRuleValue;
  }
  
  public double calcUpperBound(double oldUpperBound) {
    return Double.MAX_VALUE;
  }
  
  char tokenChar() {
    return '>';
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\ibm\icu\icu4j-core-mojang\51.2\icu4j-core-mojang-51.2.jar!\com\ibm\icu\text\AbsoluteValueSubstitution.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */