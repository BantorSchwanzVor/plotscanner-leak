package com.ibm.icu.impl.duration;

import java.util.TimeZone;

public interface DurationFormatterFactory {
  DurationFormatterFactory setPeriodFormatter(PeriodFormatter paramPeriodFormatter);
  
  DurationFormatterFactory setPeriodBuilder(PeriodBuilder paramPeriodBuilder);
  
  DurationFormatterFactory setFallback(DateFormatter paramDateFormatter);
  
  DurationFormatterFactory setFallbackLimit(long paramLong);
  
  DurationFormatterFactory setLocale(String paramString);
  
  DurationFormatterFactory setTimeZone(TimeZone paramTimeZone);
  
  DurationFormatter getFormatter();
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\ibm\icu\icu4j-core-mojang\51.2\icu4j-core-mojang-51.2.jar!\com\ibm\icu\impl\duration\DurationFormatterFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */