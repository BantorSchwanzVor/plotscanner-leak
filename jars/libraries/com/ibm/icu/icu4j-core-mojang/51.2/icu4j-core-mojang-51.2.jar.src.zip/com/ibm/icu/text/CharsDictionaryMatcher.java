package com.ibm.icu.text;

import com.ibm.icu.util.BytesTrie;
import com.ibm.icu.util.CharsTrie;
import java.text.CharacterIterator;

class CharsDictionaryMatcher extends DictionaryMatcher {
  private CharSequence characters;
  
  public CharsDictionaryMatcher(CharSequence chars) {
    this.characters = chars;
  }
  
  public int matches(CharacterIterator text_, int maxLength, int[] lengths, int[] count_, int limit, int[] values) {
    UCharacterIterator text = UCharacterIterator.getInstance(text_);
    CharsTrie uct = new CharsTrie(this.characters, 0);
    int c = text.nextCodePoint();
    BytesTrie.Result result = uct.firstForCodePoint(c);
    int numChars = 1;
    int count = 0;
    while (true) {
      if (result.hasValue()) {
        if (count < limit) {
          if (values != null)
            values[count] = uct.getValue(); 
          lengths[count] = numChars;
          count++;
        } 
        if (result == BytesTrie.Result.FINAL_VALUE)
          break; 
      } else if (result == BytesTrie.Result.NO_MATCH) {
        break;
      } 
      if (numChars >= maxLength)
        break; 
      c = text.nextCodePoint();
      numChars++;
      result = uct.nextForCodePoint(c);
    } 
    count_[0] = count;
    return numChars;
  }
  
  public int getType() {
    return 1;
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\ibm\icu\icu4j-core-mojang\51.2\icu4j-core-mojang-51.2.jar!\com\ibm\icu\text\CharsDictionaryMatcher.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */