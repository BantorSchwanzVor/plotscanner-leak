package com.ibm.icu.impl.duration;

import java.util.TimeZone;

public interface PeriodBuilderFactory {
  PeriodBuilderFactory setAvailableUnitRange(TimeUnit paramTimeUnit1, TimeUnit paramTimeUnit2);
  
  PeriodBuilderFactory setUnitIsAvailable(TimeUnit paramTimeUnit, boolean paramBoolean);
  
  PeriodBuilderFactory setMaxLimit(float paramFloat);
  
  PeriodBuilderFactory setMinLimit(float paramFloat);
  
  PeriodBuilderFactory setAllowZero(boolean paramBoolean);
  
  PeriodBuilderFactory setWeeksAloneOnly(boolean paramBoolean);
  
  PeriodBuilderFactory setAllowMilliseconds(boolean paramBoolean);
  
  PeriodBuilderFactory setLocale(String paramString);
  
  PeriodBuilderFactory setTimeZone(TimeZone paramTimeZone);
  
  PeriodBuilder getFixedUnitBuilder(TimeUnit paramTimeUnit);
  
  PeriodBuilder getSingleUnitBuilder();
  
  PeriodBuilder getOneOrTwoUnitBuilder();
  
  PeriodBuilder getMultiUnitBuilder(int paramInt);
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\ibm\icu\icu4j-core-mojang\51.2\icu4j-core-mojang-51.2.jar!\com\ibm\icu\impl\duration\PeriodBuilderFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */