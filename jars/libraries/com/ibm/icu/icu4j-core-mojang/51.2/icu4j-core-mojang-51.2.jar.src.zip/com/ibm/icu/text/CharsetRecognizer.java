package com.ibm.icu.text;

abstract class CharsetRecognizer {
  abstract String getName();
  
  public String getLanguage() {
    return null;
  }
  
  abstract CharsetMatch match(CharsetDetector paramCharsetDetector);
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\ibm\icu\icu4j-core-mojang\51.2\icu4j-core-mojang-51.2.jar!\com\ibm\icu\text\CharsetRecognizer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */