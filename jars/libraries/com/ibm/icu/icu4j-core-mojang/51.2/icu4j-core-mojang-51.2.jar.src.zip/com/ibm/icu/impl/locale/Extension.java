package com.ibm.icu.impl.locale;

public class Extension {
  private char _key;
  
  protected String _value;
  
  protected Extension(char key) {
    this._key = key;
  }
  
  Extension(char key, String value) {
    this._key = key;
    this._value = value;
  }
  
  public char getKey() {
    return this._key;
  }
  
  public String getValue() {
    return this._value;
  }
  
  public String getID() {
    return this._key + "-" + this._value;
  }
  
  public String toString() {
    return getID();
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\ibm\icu\icu4j-core-mojang\51.2\icu4j-core-mojang-51.2.jar!\com\ibm\icu\impl\locale\Extension.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */