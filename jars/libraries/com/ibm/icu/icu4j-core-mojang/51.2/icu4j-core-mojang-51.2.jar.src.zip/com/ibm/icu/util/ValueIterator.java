package com.ibm.icu.util;

public interface ValueIterator {
  boolean next(Element paramElement);
  
  void reset();
  
  void setRange(int paramInt1, int paramInt2);
  
  public static final class Element {
    public int integer;
    
    public Object value;
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\ibm\icu\icu4j-core-mojang\51.2\icu4j-core-mojang-51.2.jar!\com\ibm\ic\\util\ValueIterator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */