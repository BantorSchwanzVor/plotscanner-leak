package com.ibm.icu.impl;

public interface UCharacterNameChoice {
  public static final int UNICODE_CHAR_NAME = 0;
  
  public static final int OBSOLETE_UNUSED_UNICODE_10_CHAR_NAME = 1;
  
  public static final int EXTENDED_CHAR_NAME = 2;
  
  public static final int CHAR_NAME_ALIAS = 3;
  
  public static final int CHAR_NAME_CHOICE_COUNT = 4;
  
  public static final int ISO_COMMENT_ = 4;
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\ibm\icu\icu4j-core-mojang\51.2\icu4j-core-mojang-51.2.jar!\com\ibm\icu\impl\UCharacterNameChoice.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */