package com.mojang.authlib.yggdrasil.response;

import com.mojang.authlib.properties.PropertyMap;
import java.util.UUID;

public class HasJoinedMinecraftServerResponse extends Response {
  private UUID id;
  
  private PropertyMap properties;
  
  public UUID getId() {
    return this.id;
  }
  
  public PropertyMap getProperties() {
    return this.properties;
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\mojang\authlib\1.5.25\authlib-1.5.25.jar!\com\mojang\authlib\yggdrasil\response\HasJoinedMinecraftServerResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */