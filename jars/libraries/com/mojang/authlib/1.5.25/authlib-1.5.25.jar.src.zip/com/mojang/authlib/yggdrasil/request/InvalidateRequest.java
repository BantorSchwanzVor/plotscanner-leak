package com.mojang.authlib.yggdrasil.request;

import com.mojang.authlib.yggdrasil.YggdrasilUserAuthentication;

public class InvalidateRequest {
  private String accessToken;
  
  private String clientToken;
  
  public InvalidateRequest(YggdrasilUserAuthentication authenticationService) {
    this.accessToken = authenticationService.getAuthenticatedToken();
    this.clientToken = authenticationService.getAuthenticationService().getClientToken();
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\mojang\authlib\1.5.25\authlib-1.5.25.jar!\com\mojang\authlib\yggdrasil\request\InvalidateRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */