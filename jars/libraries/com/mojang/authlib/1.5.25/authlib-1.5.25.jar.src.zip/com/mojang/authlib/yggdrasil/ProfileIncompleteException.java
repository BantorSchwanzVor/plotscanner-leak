package com.mojang.authlib.yggdrasil;

public class ProfileIncompleteException extends RuntimeException {
  public ProfileIncompleteException() {}
  
  public ProfileIncompleteException(String message) {
    super(message);
  }
  
  public ProfileIncompleteException(String message, Throwable cause) {
    super(message, cause);
  }
  
  public ProfileIncompleteException(Throwable cause) {
    super(cause);
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\mojang\authlib\1.5.25\authlib-1.5.25.jar!\com\mojang\authlib\yggdrasil\ProfileIncompleteException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */