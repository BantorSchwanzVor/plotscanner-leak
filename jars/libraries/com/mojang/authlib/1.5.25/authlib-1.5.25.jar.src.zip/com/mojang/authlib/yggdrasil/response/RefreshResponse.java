package com.mojang.authlib.yggdrasil.response;

import com.mojang.authlib.GameProfile;

public class RefreshResponse extends Response {
  private String accessToken;
  
  private String clientToken;
  
  private GameProfile selectedProfile;
  
  private GameProfile[] availableProfiles;
  
  private User user;
  
  public String getAccessToken() {
    return this.accessToken;
  }
  
  public String getClientToken() {
    return this.clientToken;
  }
  
  public GameProfile[] getAvailableProfiles() {
    return this.availableProfiles;
  }
  
  public GameProfile getSelectedProfile() {
    return this.selectedProfile;
  }
  
  public User getUser() {
    return this.user;
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\mojang\authlib\1.5.25\authlib-1.5.25.jar!\com\mojang\authlib\yggdrasil\response\RefreshResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */