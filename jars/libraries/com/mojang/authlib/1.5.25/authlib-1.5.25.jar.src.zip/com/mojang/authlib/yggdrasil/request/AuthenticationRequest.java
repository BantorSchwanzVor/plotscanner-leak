package com.mojang.authlib.yggdrasil.request;

import com.mojang.authlib.Agent;
import com.mojang.authlib.yggdrasil.YggdrasilUserAuthentication;

public class AuthenticationRequest {
  private Agent agent;
  
  private String username;
  
  private String password;
  
  private String clientToken;
  
  private boolean requestUser = true;
  
  public AuthenticationRequest(YggdrasilUserAuthentication authenticationService, String username, String password) {
    this.agent = authenticationService.getAgent();
    this.username = username;
    this.clientToken = authenticationService.getAuthenticationService().getClientToken();
    this.password = password;
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\mojang\authlib\1.5.25\authlib-1.5.25.jar!\com\mojang\authlib\yggdrasil\request\AuthenticationRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */