package com.mojang.realmsclient.dto;

public class PlayerInfo {
  private String name;
  
  private String uuid;
  
  private boolean operator = false;
  
  private boolean accepted = false;
  
  private boolean online = false;
  
  public String getName() {
    return this.name;
  }
  
  public void setName(String name) {
    this.name = name;
  }
  
  public String getUuid() {
    return this.uuid;
  }
  
  public void setUuid(String uuid) {
    this.uuid = uuid;
  }
  
  public boolean isOperator() {
    return this.operator;
  }
  
  public void setOperator(boolean operator) {
    this.operator = operator;
  }
  
  public boolean getAccepted() {
    return this.accepted;
  }
  
  public void setAccepted(boolean accepted) {
    this.accepted = accepted;
  }
  
  public boolean getOnline() {
    return this.online;
  }
  
  public void setOnline(boolean online) {
    this.online = online;
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\mojang\realms\1.10.22\realms-1.10.22.jar!\com\mojang\realmsclient\dto\PlayerInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */