package com.mojang.realmsclient.util;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import javax.annotation.Nullable;

public class SkinProcessor {
  private int[] pixels;
  
  private int width;
  
  private int height;
  
  @Nullable
  public BufferedImage process(BufferedImage image) {
    if (image == null)
      return null; 
    this.width = 64;
    this.height = 64;
    BufferedImage out = new BufferedImage(this.width, this.height, 2);
    Graphics outGraphics = out.getGraphics();
    outGraphics.drawImage(image, 0, 0, null);
    boolean isLegacy = (image.getHeight() == 32);
    if (isLegacy) {
      outGraphics.setColor(new Color(0, 0, 0, 0));
      outGraphics.fillRect(0, 32, 64, 32);
      outGraphics.drawImage(out, 24, 48, 20, 52, 4, 16, 8, 20, null);
      outGraphics.drawImage(out, 28, 48, 24, 52, 8, 16, 12, 20, null);
      outGraphics.drawImage(out, 20, 52, 16, 64, 8, 20, 12, 32, null);
      outGraphics.drawImage(out, 24, 52, 20, 64, 4, 20, 8, 32, null);
      outGraphics.drawImage(out, 28, 52, 24, 64, 0, 20, 4, 32, null);
      outGraphics.drawImage(out, 32, 52, 28, 64, 12, 20, 16, 32, null);
      outGraphics.drawImage(out, 40, 48, 36, 52, 44, 16, 48, 20, null);
      outGraphics.drawImage(out, 44, 48, 40, 52, 48, 16, 52, 20, null);
      outGraphics.drawImage(out, 36, 52, 32, 64, 48, 20, 52, 32, null);
      outGraphics.drawImage(out, 40, 52, 36, 64, 44, 20, 48, 32, null);
      outGraphics.drawImage(out, 44, 52, 40, 64, 40, 20, 44, 32, null);
      outGraphics.drawImage(out, 48, 52, 44, 64, 52, 20, 56, 32, null);
    } 
    outGraphics.dispose();
    this.pixels = ((DataBufferInt)out.getRaster().getDataBuffer()).getData();
    setNoAlpha(0, 0, 32, 16);
    if (isLegacy)
      doNotchTransparencyHack(32, 0, 64, 32); 
    setNoAlpha(0, 16, 64, 32);
    setNoAlpha(16, 48, 48, 64);
    return out;
  }
  
  private void doNotchTransparencyHack(int x0, int y0, int x1, int y1) {
    int x;
    for (x = x0; x < x1; x++) {
      for (int y = y0; y < y1; y++) {
        int pix = this.pixels[x + y * this.width];
        if ((pix >> 24 & 0xFF) < 128)
          return; 
      } 
    } 
    for (x = x0; x < x1; x++) {
      for (int y = y0; y < y1; y++)
        this.pixels[x + y * this.width] = this.pixels[x + y * this.width] & 0xFFFFFF; 
    } 
  }
  
  private void setNoAlpha(int x0, int y0, int x1, int y1) {
    for (int x = x0; x < x1; x++) {
      for (int y = y0; y < y1; y++)
        this.pixels[x + y * this.width] = this.pixels[x + y * this.width] | 0xFF000000; 
    } 
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\mojang\realms\1.10.22\realms-1.10.22.jar!\com\mojang\realmsclien\\util\SkinProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */