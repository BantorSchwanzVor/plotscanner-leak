package com.mojang.realmsclient.dto;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class RealmsServerPlayerLists extends ValueObject {
  private static final Logger LOGGER = LogManager.getLogger();
  
  public List<RealmsServerPlayerList> servers;
  
  public static RealmsServerPlayerLists parse(String json) {
    RealmsServerPlayerLists list = new RealmsServerPlayerLists();
    list.servers = new ArrayList<>();
    try {
      JsonParser parser = new JsonParser();
      JsonObject object = parser.parse(json).getAsJsonObject();
      if (object.get("lists").isJsonArray()) {
        JsonArray jsonArray = object.get("lists").getAsJsonArray();
        Iterator<JsonElement> it = jsonArray.iterator();
        while (it.hasNext())
          list.servers.add(RealmsServerPlayerList.parse(((JsonElement)it.next()).getAsJsonObject())); 
      } 
    } catch (Exception e) {
      LOGGER.error("Could not parse RealmsServerPlayerLists: " + e.getMessage());
    } 
    return list;
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\mojang\realms\1.10.22\realms-1.10.22.jar!\com\mojang\realmsclient\dto\RealmsServerPlayerLists.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */