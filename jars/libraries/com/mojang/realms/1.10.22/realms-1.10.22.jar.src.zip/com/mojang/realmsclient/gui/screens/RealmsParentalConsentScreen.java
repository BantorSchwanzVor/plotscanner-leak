package com.mojang.realmsclient.gui.screens;

import com.mojang.realmsclient.gui.RealmsConstants;
import com.mojang.realmsclient.util.RealmsUtil;
import net.minecraft.realms.Realms;
import net.minecraft.realms.RealmsButton;
import net.minecraft.realms.RealmsScreen;
import org.lwjgl.opengl.GL11;

public class RealmsParentalConsentScreen extends RealmsScreen {
  private final RealmsScreen nextScreen;
  
  private static final int BUTTON_BACK_ID = 0;
  
  private static final int BUTTON_OK_ID = 1;
  
  private boolean onLink;
  
  public RealmsParentalConsentScreen(RealmsScreen nextScreen) {
    this.nextScreen = nextScreen;
  }
  
  public void init() {
    buttonsClear();
    String updateAccount = getLocalizedString("mco.account.update");
    String back = getLocalizedString("gui.back");
    int buttonWidth = Math.max(fontWidth(updateAccount), fontWidth(back)) + 30;
    buttonsAdd(new RealmsButton(0, width() / 2 - buttonWidth + 5, RealmsConstants.row(13), buttonWidth, 20, back));
    buttonsAdd(new RealmsButton(1, width() / 2 + 5, RealmsConstants.row(13), buttonWidth, 20, updateAccount));
  }
  
  public void tick() {
    super.tick();
  }
  
  public void buttonClicked(RealmsButton button) {
    switch (button.id()) {
      case 1:
        RealmsUtil.browseTo("https://minecraft.net/update-account");
        return;
      case 0:
        Realms.setScreen(this.nextScreen);
        return;
    } 
  }
  
  public void render(int xm, int ym, float a) {
    renderBackground();
    String translatedText = getLocalizedString("mco.account.privacyinfo");
    int y = 15;
    for (String lineBrokenOnExplicits : translatedText.split("\\\\n")) {
      drawCenteredString(lineBrokenOnExplicits, width() / 2, y, 16777215);
      y += 15;
    } 
    renderLink(xm, ym, y);
    super.render(xm, ym, a);
  }
  
  public void mouseClicked(int x, int y, int buttonNum) {
    if (this.onLink)
      RealmsUtil.browseTo("https://minecraft.net/privacy/gdpr/"); 
  }
  
  private void renderLink(int xm, int ym, int top) {
    String text = getLocalizedString("mco.account.privacy.info");
    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    GL11.glPushMatrix();
    int textWidth = fontWidth(text);
    int leftPadding = width() / 2 - textWidth / 2;
    int x1 = leftPadding;
    int x2 = x1 + textWidth + 1;
    int y1 = top;
    int y2 = y1 + fontLineHeight();
    GL11.glTranslatef(x1, y1, 0.0F);
    if (x1 <= xm && xm <= x2 && y1 <= ym && ym <= y2) {
      this.onLink = true;
      drawString(text, 0, 0, 7107012);
    } else {
      this.onLink = false;
      drawString(text, 0, 0, 3368635);
    } 
    GL11.glPopMatrix();
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\mojang\realms\1.10.22\realms-1.10.22.jar!\com\mojang\realmsclient\gui\screens\RealmsParentalConsentScreen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */