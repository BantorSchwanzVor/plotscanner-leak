package com.mojang.realmsclient.gui.screens;

import com.mojang.realmsclient.client.RealmsClient;
import com.mojang.realmsclient.dto.RealmsServer;
import com.mojang.realmsclient.dto.Subscription;
import com.mojang.realmsclient.exception.RealmsServiceException;
import com.mojang.realmsclient.gui.RealmsConstants;
import com.mojang.realmsclient.util.RealmsUtil;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.io.IOException;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;
import net.minecraft.realms.Realms;
import net.minecraft.realms.RealmsButton;
import net.minecraft.realms.RealmsScreen;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.input.Keyboard;

public class RealmsSubscriptionInfoScreen extends RealmsScreen {
  private static final Logger LOGGER = LogManager.getLogger();
  
  private final RealmsScreen lastScreen;
  
  private final RealmsServer serverData;
  
  private final RealmsScreen mainScreen;
  
  private final int BUTTON_BACK_ID = 0;
  
  private final int BUTTON_DELETE_ID = 1;
  
  private final int BUTTON_SUBSCRIPTION_ID = 2;
  
  private int daysLeft;
  
  private String startDate;
  
  private Subscription.SubscriptionType type;
  
  private final String PURCHASE_LINK = "https://account.mojang.com/buy/realms";
  
  public RealmsSubscriptionInfoScreen(RealmsScreen lastScreen, RealmsServer serverData, RealmsScreen mainScreen) {
    this.lastScreen = lastScreen;
    this.serverData = serverData;
    this.mainScreen = mainScreen;
  }
  
  public void init() {
    getSubscription(this.serverData.id);
    Keyboard.enableRepeatEvents(true);
    buttonsAdd(newButton(2, width() / 2 - 100, RealmsConstants.row(6), getLocalizedString("mco.configure.world.subscription.extend")));
    buttonsAdd(newButton(0, width() / 2 - 100, RealmsConstants.row(12), getLocalizedString("gui.back")));
    if (this.serverData.expired)
      buttonsAdd(newButton(1, width() / 2 - 100, RealmsConstants.row(10), getLocalizedString("mco.configure.world.delete.button"))); 
  }
  
  private void getSubscription(long worldId) {
    RealmsClient client = RealmsClient.createRealmsClient();
    try {
      Subscription subscription = client.subscriptionFor(worldId);
      this.daysLeft = subscription.daysLeft;
      this.startDate = localPresentation(subscription.startDate);
      this.type = subscription.type;
    } catch (RealmsServiceException e) {
      LOGGER.error("Couldn't get subscription");
      Realms.setScreen(new RealmsGenericErrorScreen(e, this.lastScreen));
    } catch (IOException ignored) {
      LOGGER.error("Couldn't parse response subscribing");
    } 
  }
  
  public void confirmResult(boolean result, int id) {
    if (id == 1 && result)
      (new Thread("Realms-delete-realm") {
          public void run() {
            try {
              RealmsClient client = RealmsClient.createRealmsClient();
              client.deleteWorld(RealmsSubscriptionInfoScreen.this.serverData.id);
            } catch (RealmsServiceException e) {
              RealmsSubscriptionInfoScreen.LOGGER.error("Couldn't delete world");
              RealmsSubscriptionInfoScreen.LOGGER.error(e);
            } catch (IOException e) {
              RealmsSubscriptionInfoScreen.LOGGER.error("Couldn't delete world");
              e.printStackTrace();
            } 
            Realms.setScreen(RealmsSubscriptionInfoScreen.this.mainScreen);
          }
        }).start(); 
    Realms.setScreen(this);
  }
  
  private String localPresentation(long cetTime) {
    Calendar cal = new GregorianCalendar(TimeZone.getDefault());
    cal.setTimeInMillis(cetTime);
    return DateFormat.getDateTimeInstance().format(cal.getTime());
  }
  
  public void removed() {
    Keyboard.enableRepeatEvents(false);
  }
  
  public void buttonClicked(RealmsButton button) {
    String extensionUrl;
    Clipboard clipboard;
    String line2;
    String line3;
    if (!button.active())
      return; 
    switch (button.id()) {
      case 0:
        Realms.setScreen(this.lastScreen);
        break;
      case 2:
        extensionUrl = "https://account.mojang.com/buy/realms?sid=" + this.serverData.remoteSubscriptionId + "&pid=" + Realms.getUUID();
        clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        clipboard.setContents(new StringSelection(extensionUrl), null);
        RealmsUtil.browseTo(extensionUrl);
        break;
      case 1:
        line2 = getLocalizedString("mco.configure.world.delete.question.line1");
        line3 = getLocalizedString("mco.configure.world.delete.question.line2");
        Realms.setScreen(new RealmsLongConfirmationScreen(this, RealmsLongConfirmationScreen.Type.Warning, line2, line3, true, 1));
        break;
    } 
  }
  
  public void keyPressed(char ch, int eventKey) {
    if (eventKey == 1)
      Realms.setScreen(this.lastScreen); 
  }
  
  public void render(int xm, int ym, float a) {
    renderBackground();
    int center = width() / 2 - 100;
    drawCenteredString(getLocalizedString("mco.configure.world.subscription.title"), width() / 2, 17, 16777215);
    drawString(getLocalizedString("mco.configure.world.subscription.start"), center, RealmsConstants.row(0), 10526880);
    drawString(this.startDate, center, RealmsConstants.row(1), 16777215);
    if (this.type == Subscription.SubscriptionType.NORMAL) {
      drawString(getLocalizedString("mco.configure.world.subscription.timeleft"), center, RealmsConstants.row(3), 10526880);
    } else if (this.type == Subscription.SubscriptionType.RECURRING) {
      drawString(getLocalizedString("mco.configure.world.subscription.recurring.daysleft"), center, RealmsConstants.row(3), 10526880);
    } 
    drawString(daysLeftPresentation(this.daysLeft), center, RealmsConstants.row(4), 16777215);
    super.render(xm, ym, a);
  }
  
  private String daysLeftPresentation(int daysLeft) {
    if (daysLeft == -1 && this.serverData.expired)
      return getLocalizedString("mco.configure.world.subscription.expired"); 
    if (daysLeft <= 1)
      return getLocalizedString("mco.configure.world.subscription.less_than_a_day"); 
    int months = daysLeft / 30;
    int days = daysLeft % 30;
    StringBuilder sb = new StringBuilder();
    if (months > 0) {
      sb.append(months).append(" ");
      if (months == 1) {
        sb.append(getLocalizedString("mco.configure.world.subscription.month").toLowerCase(Locale.ROOT));
      } else {
        sb.append(getLocalizedString("mco.configure.world.subscription.months").toLowerCase(Locale.ROOT));
      } 
    } 
    if (days > 0) {
      if (sb.length() > 0)
        sb.append(", "); 
      sb.append(days).append(" ");
      if (days == 1) {
        sb.append(getLocalizedString("mco.configure.world.subscription.day").toLowerCase(Locale.ROOT));
      } else {
        sb.append(getLocalizedString("mco.configure.world.subscription.days").toLowerCase(Locale.ROOT));
      } 
    } 
    return sb.toString();
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\mojang\realms\1.10.22\realms-1.10.22.jar!\com\mojang\realmsclient\gui\screens\RealmsSubscriptionInfoScreen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */