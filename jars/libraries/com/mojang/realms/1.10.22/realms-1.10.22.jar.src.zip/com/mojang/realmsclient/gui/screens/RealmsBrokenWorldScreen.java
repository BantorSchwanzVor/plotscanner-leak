package com.mojang.realmsclient.gui.screens;

import com.mojang.realmsclient.RealmsMainScreen;
import com.mojang.realmsclient.client.RealmsClient;
import com.mojang.realmsclient.dto.RealmsServer;
import com.mojang.realmsclient.dto.RealmsWorldOptions;
import com.mojang.realmsclient.dto.WorldDownload;
import com.mojang.realmsclient.exception.RealmsServiceException;
import com.mojang.realmsclient.gui.LongRunningTask;
import com.mojang.realmsclient.gui.RealmsConstants;
import com.mojang.realmsclient.util.RealmsTasks;
import com.mojang.realmsclient.util.RealmsTextureManager;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import net.minecraft.realms.Realms;
import net.minecraft.realms.RealmsButton;
import net.minecraft.realms.RealmsMth;
import net.minecraft.realms.RealmsScreen;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

public class RealmsBrokenWorldScreen extends RealmsScreen {
  private static final Logger LOGGER = LogManager.getLogger();
  
  private static final String SLOT_FRAME_LOCATION = "realms:textures/gui/realms/slot_frame.png";
  
  private static final String EMPTY_FRAME_LOCATION = "realms:textures/gui/realms/empty_frame.png";
  
  private final RealmsScreen lastScreen;
  
  private final RealmsMainScreen mainScreen;
  
  private RealmsServer serverData;
  
  private final long serverId;
  
  private String title = getLocalizedString("mco.brokenworld.title");
  
  private String message = getLocalizedString("mco.brokenworld.message.line1") + "\\n" + getLocalizedString("mco.brokenworld.message.line2");
  
  private int left_x;
  
  private int right_x;
  
  private final int default_button_width = 80;
  
  private final int default_button_offset = 5;
  
  private static final int BUTTON_BACK_ID = 0;
  
  private static final List<Integer> playButtonIds = Arrays.asList(new Integer[] { Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(3) });
  
  private static final List<Integer> resetButtonIds = Arrays.asList(new Integer[] { Integer.valueOf(4), Integer.valueOf(5), Integer.valueOf(6) });
  
  private static final List<Integer> downloadButtonIds = Arrays.asList(new Integer[] { Integer.valueOf(7), Integer.valueOf(8), Integer.valueOf(9) });
  
  private static final List<Integer> downloadConfirmationIds = Arrays.asList(new Integer[] { Integer.valueOf(10), Integer.valueOf(11), Integer.valueOf(12) });
  
  private final List<Integer> slotsThatHasBeenDownloaded = new ArrayList<>();
  
  private static final int SWITCH_SLOT_ID_RESULT = 13;
  
  private static final int RESET_CONFIRMATION_ID = 14;
  
  private int animTick;
  
  public RealmsBrokenWorldScreen(RealmsScreen lastScreen, RealmsMainScreen mainScreen, long serverId) {
    this.lastScreen = lastScreen;
    this.mainScreen = mainScreen;
    this.serverId = serverId;
  }
  
  public void setTitle(String title) {
    this.title = title;
  }
  
  public void mouseEvent() {
    super.mouseEvent();
  }
  
  public void init() {
    buttonsClear();
    this.left_x = width() / 2 - 150;
    this.right_x = width() / 2 + 190;
    buttonsAdd(newButton(0, this.right_x - 80 + 8, RealmsConstants.row(13) - 5, 70, 20, getLocalizedString("gui.back")));
    if (this.serverData == null) {
      fetchServerData(this.serverId);
    } else {
      addButtons();
    } 
    Keyboard.enableRepeatEvents(true);
  }
  
  public void addButtons() {
    for (Map.Entry<Integer, RealmsWorldOptions> entry : (Iterable<Map.Entry<Integer, RealmsWorldOptions>>)this.serverData.slots.entrySet()) {
      RealmsWorldOptions slot = entry.getValue();
      boolean canPlay = (((Integer)entry.getKey()).intValue() != this.serverData.activeSlot || this.serverData.worldType.equals(RealmsServer.WorldType.MINIGAME));
      RealmsButton downloadButton = newButton(canPlay ? ((Integer)playButtonIds.get(((Integer)entry.getKey()).intValue() - 1)).intValue() : ((Integer)downloadButtonIds.get(((Integer)entry.getKey()).intValue() - 1)).intValue(), getFramePositionX(((Integer)entry.getKey()).intValue()), RealmsConstants.row(8), 80, 20, getLocalizedString(canPlay ? "mco.brokenworld.play" : "mco.brokenworld.download"));
      if (this.slotsThatHasBeenDownloaded.contains(entry.getKey())) {
        downloadButton.active(false);
        downloadButton.msg(getLocalizedString("mco.brokenworld.downloaded"));
      } 
      buttonsAdd(downloadButton);
      buttonsAdd(newButton(((Integer)resetButtonIds.get(((Integer)entry.getKey()).intValue() - 1)).intValue(), getFramePositionX(((Integer)entry.getKey()).intValue()), RealmsConstants.row(10), 80, 20, getLocalizedString("mco.brokenworld.reset")));
    } 
  }
  
  public void tick() {
    this.animTick++;
  }
  
  public void render(int xm, int ym, float a) {
    renderBackground();
    super.render(xm, ym, a);
    drawCenteredString(this.title, width() / 2, 17, 16777215);
    String[] lines = this.message.split("\\\\n");
    for (int i = 0; i < lines.length; i++)
      drawCenteredString(lines[i], width() / 2, RealmsConstants.row(-1) + 3 + i * 12, 10526880); 
    if (this.serverData == null)
      return; 
    for (Map.Entry<Integer, RealmsWorldOptions> entry : (Iterable<Map.Entry<Integer, RealmsWorldOptions>>)this.serverData.slots.entrySet()) {
      if (((RealmsWorldOptions)entry.getValue()).templateImage != null && ((RealmsWorldOptions)entry.getValue()).templateId != -1L) {
        drawSlotFrame(getFramePositionX(((Integer)entry.getKey()).intValue()), RealmsConstants.row(1) + 5, xm, ym, (this.serverData.activeSlot == ((Integer)entry.getKey()).intValue() && !isMinigame()), ((RealmsWorldOptions)entry.getValue()).getSlotName(((Integer)entry.getKey()).intValue()), ((Integer)entry.getKey()).intValue(), ((RealmsWorldOptions)entry.getValue()).templateId, ((RealmsWorldOptions)entry.getValue()).templateImage, ((RealmsWorldOptions)entry.getValue()).empty);
        continue;
      } 
      drawSlotFrame(getFramePositionX(((Integer)entry.getKey()).intValue()), RealmsConstants.row(1) + 5, xm, ym, (this.serverData.activeSlot == ((Integer)entry.getKey()).intValue() && !isMinigame()), ((RealmsWorldOptions)entry.getValue()).getSlotName(((Integer)entry.getKey()).intValue()), ((Integer)entry.getKey()).intValue(), -1L, (String)null, ((RealmsWorldOptions)entry.getValue()).empty);
    } 
  }
  
  private int getFramePositionX(int i) {
    return this.left_x + (i - 1) * 110;
  }
  
  public void removed() {
    Keyboard.enableRepeatEvents(false);
  }
  
  public void buttonClicked(RealmsButton button) {
    if (!button.active())
      return; 
    if (playButtonIds.contains(Integer.valueOf(button.id()))) {
      int slot = playButtonIds.indexOf(Integer.valueOf(button.id())) + 1;
      if (((RealmsWorldOptions)this.serverData.slots.get(Integer.valueOf(slot))).empty) {
        RealmsResetWorldScreen resetWorldScreen = new RealmsResetWorldScreen(this, this.serverData, this, getLocalizedString("mco.configure.world.switch.slot"), getLocalizedString("mco.configure.world.switch.slot.subtitle"), 10526880, getLocalizedString("gui.cancel"));
        resetWorldScreen.setSlot(slot);
        resetWorldScreen.setResetTitle(getLocalizedString("mco.create.world.reset.title"));
        resetWorldScreen.setConfirmationId(14);
        Realms.setScreen(resetWorldScreen);
      } else {
        switchSlot(slot);
      } 
    } else if (resetButtonIds.contains(Integer.valueOf(button.id()))) {
      int slot = resetButtonIds.indexOf(Integer.valueOf(button.id())) + 1;
      RealmsResetWorldScreen realmsResetWorldScreen = new RealmsResetWorldScreen(this, this.serverData, this);
      if (slot != this.serverData.activeSlot || this.serverData.worldType.equals(RealmsServer.WorldType.MINIGAME))
        realmsResetWorldScreen.setSlot(slot); 
      realmsResetWorldScreen.setConfirmationId(14);
      Realms.setScreen(realmsResetWorldScreen);
    } else if (downloadButtonIds.contains(Integer.valueOf(button.id()))) {
      String line2 = getLocalizedString("mco.configure.world.restore.download.question.line1");
      String line3 = getLocalizedString("mco.configure.world.restore.download.question.line2");
      Realms.setScreen(new RealmsLongConfirmationScreen(this, RealmsLongConfirmationScreen.Type.Info, line2, line3, true, button.id()));
    } else if (button.id() == 0) {
      backButtonClicked();
    } 
  }
  
  public void keyPressed(char ch, int eventKey) {
    if (eventKey == 1)
      backButtonClicked(); 
  }
  
  private void backButtonClicked() {
    Realms.setScreen(this.lastScreen);
  }
  
  private void fetchServerData(final long worldId) {
    (new Thread() {
        public void run() {
          RealmsClient client = RealmsClient.createRealmsClient();
          try {
            RealmsBrokenWorldScreen.this.serverData = client.getOwnWorld(worldId);
            RealmsBrokenWorldScreen.this.addButtons();
          } catch (RealmsServiceException e) {
            RealmsBrokenWorldScreen.LOGGER.error("Couldn't get own world");
            Realms.setScreen(new RealmsGenericErrorScreen(e.getMessage(), RealmsBrokenWorldScreen.this.lastScreen));
          } catch (IOException ignored) {
            RealmsBrokenWorldScreen.LOGGER.error("Couldn't parse response getting own world");
          } 
        }
      }).start();
  }
  
  public void confirmResult(boolean result, int id) {
    if (!result) {
      Realms.setScreen(this);
      return;
    } 
    if (id == 13 || id == 14) {
      (new Thread() {
          public void run() {
            RealmsClient client = RealmsClient.createRealmsClient();
            if (RealmsBrokenWorldScreen.this.serverData.state.equals(RealmsServer.State.CLOSED)) {
              RealmsTasks.OpenServerTask openServerTask = new RealmsTasks.OpenServerTask(RealmsBrokenWorldScreen.this.serverData, RealmsBrokenWorldScreen.this, RealmsBrokenWorldScreen.this.lastScreen, true);
              RealmsLongRunningMcoTaskScreen openWorldLongRunningTaskScreen = new RealmsLongRunningMcoTaskScreen(RealmsBrokenWorldScreen.this, (LongRunningTask)openServerTask);
              openWorldLongRunningTaskScreen.start();
              Realms.setScreen(openWorldLongRunningTaskScreen);
            } else {
              try {
                RealmsBrokenWorldScreen.this.mainScreen.newScreen().play(client.getOwnWorld(RealmsBrokenWorldScreen.this.serverId), RealmsBrokenWorldScreen.this);
              } catch (RealmsServiceException e) {
                RealmsBrokenWorldScreen.LOGGER.error("Couldn't get own world");
                Realms.setScreen(RealmsBrokenWorldScreen.this.lastScreen);
              } catch (IOException ignored) {
                RealmsBrokenWorldScreen.LOGGER.error("Couldn't parse response getting own world");
                Realms.setScreen(RealmsBrokenWorldScreen.this.lastScreen);
              } 
            } 
          }
        }).start();
    } else if (downloadButtonIds.contains(Integer.valueOf(id))) {
      downloadWorld(downloadButtonIds.indexOf(Integer.valueOf(id)) + 1);
    } else if (downloadConfirmationIds.contains(Integer.valueOf(id))) {
      this.slotsThatHasBeenDownloaded.add(Integer.valueOf(downloadConfirmationIds.indexOf(Integer.valueOf(id)) + 1));
      buttonsClear();
      addButtons();
    } 
  }
  
  private void downloadWorld(int slotId) {
    RealmsClient client = RealmsClient.createRealmsClient();
    try {
      WorldDownload worldDownload = client.download(this.serverData.id, slotId);
      RealmsDownloadLatestWorldScreen downloadScreen = new RealmsDownloadLatestWorldScreen(this, worldDownload, this.serverData.name + " (" + ((RealmsWorldOptions)this.serverData.slots.get(Integer.valueOf(slotId))).getSlotName(slotId) + ")");
      downloadScreen.setConfirmationId(((Integer)downloadConfirmationIds.get(slotId - 1)).intValue());
      Realms.setScreen(downloadScreen);
    } catch (RealmsServiceException e) {
      LOGGER.error("Couldn't download world data");
      Realms.setScreen(new RealmsGenericErrorScreen(e, this));
    } 
  }
  
  private boolean isMinigame() {
    return (this.serverData != null && this.serverData.worldType.equals(RealmsServer.WorldType.MINIGAME));
  }
  
  private void drawSlotFrame(int x, int y, int xm, int ym, boolean active, String text, int i, long imageId, String image, boolean empty) {
    if (empty) {
      bind("realms:textures/gui/realms/empty_frame.png");
    } else if (image != null && imageId != -1L) {
      RealmsTextureManager.bindWorldTemplate(String.valueOf(imageId), image);
    } else if (i == 1) {
      bind("textures/gui/title/background/panorama_0.png");
    } else if (i == 2) {
      bind("textures/gui/title/background/panorama_2.png");
    } else if (i == 3) {
      bind("textures/gui/title/background/panorama_3.png");
    } else {
      RealmsTextureManager.bindWorldTemplate(String.valueOf(this.serverData.minigameId), this.serverData.minigameImage);
    } 
    if (!active) {
      GL11.glColor4f(0.56F, 0.56F, 0.56F, 1.0F);
    } else if (active) {
      float c = 0.9F + 0.1F * RealmsMth.cos(this.animTick * 0.2F);
      GL11.glColor4f(c, c, c, 1.0F);
    } 
    RealmsScreen.blit(x + 3, y + 3, 0.0F, 0.0F, 74, 74, 74.0F, 74.0F);
    bind("realms:textures/gui/realms/slot_frame.png");
    if (active) {
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    } else {
      GL11.glColor4f(0.56F, 0.56F, 0.56F, 1.0F);
    } 
    RealmsScreen.blit(x, y, 0.0F, 0.0F, 80, 80, 80.0F, 80.0F);
    drawCenteredString(text, x + 40, y + 66, 16777215);
  }
  
  private void switchSlot(int id) {
    RealmsTasks.SwitchSlotTask switchSlotTask = new RealmsTasks.SwitchSlotTask(this.serverData.id, id, this, 13);
    RealmsLongRunningMcoTaskScreen longRunningMcoTaskScreen = new RealmsLongRunningMcoTaskScreen(this.lastScreen, (LongRunningTask)switchSlotTask);
    longRunningMcoTaskScreen.start();
    Realms.setScreen(longRunningMcoTaskScreen);
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\mojang\realms\1.10.22\realms-1.10.22.jar!\com\mojang\realmsclient\gui\screens\RealmsBrokenWorldScreen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */