package com.mojang.realmsclient.client;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.realmsclient.util.JsonUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class RealmsError {
  private static final Logger LOGGER = LogManager.getLogger();
  
  private String errorMessage;
  
  private int errorCode;
  
  public RealmsError(String error) {
    try {
      JsonParser parser = new JsonParser();
      JsonObject object = parser.parse(error).getAsJsonObject();
      this.errorMessage = JsonUtils.getStringOr("errorMsg", object, "");
      this.errorCode = JsonUtils.getIntOr("errorCode", object, -1);
    } catch (Exception e) {
      LOGGER.error("Could not parse RealmsError: " + e.getMessage());
      LOGGER.error("The error was: " + error);
    } 
  }
  
  public String getErrorMessage() {
    return this.errorMessage;
  }
  
  public int getErrorCode() {
    return this.errorCode;
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\mojang\realms\1.10.22\realms-1.10.22.jar!\com\mojang\realmsclient\client\RealmsError.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */