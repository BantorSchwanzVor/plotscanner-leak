package com.mojang.realmsclient.gui.screens;

import com.mojang.realmsclient.client.RealmsClient;
import com.mojang.realmsclient.dto.RealmsServer;
import com.mojang.realmsclient.dto.WorldTemplate;
import com.mojang.realmsclient.dto.WorldTemplatePaginatedList;
import com.mojang.realmsclient.exception.RealmsServiceException;
import com.mojang.realmsclient.gui.LongRunningTask;
import com.mojang.realmsclient.gui.RealmsConstants;
import com.mojang.realmsclient.util.RealmsTasks;
import com.mojang.realmsclient.util.RealmsTextureManager;
import net.minecraft.realms.Realms;
import net.minecraft.realms.RealmsButton;
import net.minecraft.realms.RealmsScreen;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

public class RealmsResetWorldScreen extends RealmsScreenWithCallback<WorldTemplate> {
  private static final Logger LOGGER = LogManager.getLogger();
  
  private final RealmsScreen lastScreen;
  
  private final RealmsServer serverData;
  
  private final RealmsScreen returnScreen;
  
  private String title = getLocalizedString("mco.reset.world.title");
  
  private String subtitle = getLocalizedString("mco.reset.world.warning");
  
  private String buttonTitle = getLocalizedString("gui.cancel");
  
  private int subtitleColor = 16711680;
  
  private static final String SLOT_FRAME_LOCATION = "realms:textures/gui/realms/slot_frame.png";
  
  private static final String UPLOAD_LOCATION = "realms:textures/gui/realms/upload.png";
  
  private static final String ADVENTURE_MAP_LOCATION = "realms:textures/gui/realms/adventure.png";
  
  private static final String SURVIVAL_SPAWN_LOCATION = "realms:textures/gui/realms/survival_spawn.png";
  
  private static final String NEW_WORLD_LOCATION = "realms:textures/gui/realms/new_world.png";
  
  private static final String EXPERIENCE_LOCATION = "realms:textures/gui/realms/experience.png";
  
  private static final String INSPIRATION_LOCATION = "realms:textures/gui/realms/inspiration.png";
  
  private final int BUTTON_CANCEL_ID = 0;
  
  private final WorldTemplatePaginatedList templates = new WorldTemplatePaginatedList();
  
  private final WorldTemplatePaginatedList adventuremaps = new WorldTemplatePaginatedList();
  
  private final WorldTemplatePaginatedList experiences = new WorldTemplatePaginatedList();
  
  private final WorldTemplatePaginatedList inspirations = new WorldTemplatePaginatedList();
  
  private ResetType selectedType = ResetType.NONE;
  
  public int slot = -1;
  
  private ResetType typeToReset = ResetType.NONE;
  
  private ResetWorldInfo worldInfoToReset = null;
  
  private WorldTemplate worldTemplateToReset = null;
  
  private String resetTitle = null;
  
  private int confirmationId = -1;
  
  public RealmsResetWorldScreen(RealmsScreen lastScreen, RealmsServer serverData, RealmsScreen returnScreen) {
    this.lastScreen = lastScreen;
    this.serverData = serverData;
    this.returnScreen = returnScreen;
  }
  
  public RealmsResetWorldScreen(RealmsScreen lastScreen, RealmsServer serverData, RealmsScreen returnScreen, String title, String subtitle, int subtitleColor, String buttonTitle) {
    this(lastScreen, serverData, returnScreen);
    this.title = title;
    this.subtitle = subtitle;
    this.subtitleColor = subtitleColor;
    this.buttonTitle = buttonTitle;
  }
  
  public void setConfirmationId(int confirmationId) {
    this.confirmationId = confirmationId;
  }
  
  public void setSlot(int slot) {
    this.slot = slot;
  }
  
  public void setResetTitle(String title) {
    this.resetTitle = title;
  }
  
  public void init() {
    buttonsClear();
    buttonsAdd(newButton(0, width() / 2 - 40, RealmsConstants.row(14) - 10, 80, 20, this.buttonTitle));
    (new Thread("Realms-reset-world-fetcher") {
        public void run() {
          RealmsClient client = RealmsClient.createRealmsClient();
          try {
            RealmsResetWorldScreen.this.templates.set(client.fetchWorldTemplates(1, 10, RealmsServer.WorldType.NORMAL));
            RealmsResetWorldScreen.this.adventuremaps.set(client.fetchWorldTemplates(1, 10, RealmsServer.WorldType.ADVENTUREMAP));
            RealmsResetWorldScreen.this.experiences.set(client.fetchWorldTemplates(1, 10, RealmsServer.WorldType.EXPERIENCE));
            RealmsResetWorldScreen.this.inspirations.set(client.fetchWorldTemplates(1, 10, RealmsServer.WorldType.INSPIRATION));
          } catch (RealmsServiceException e) {
            RealmsResetWorldScreen.LOGGER.error("Couldn't fetch templates in reset world", (Throwable)e);
          } 
        }
      }).start();
  }
  
  public void removed() {
    Keyboard.enableRepeatEvents(false);
  }
  
  public void keyPressed(char ch, int eventKey) {
    if (eventKey == 1)
      Realms.setScreen(this.lastScreen); 
  }
  
  public void buttonClicked(RealmsButton button) {
    if (!button.active())
      return; 
    if (button.id() == 0)
      Realms.setScreen(this.lastScreen); 
  }
  
  public void mouseClicked(int x, int y, int buttonNum) {
    RealmsSelectWorldTemplateScreen screen;
    RealmsSelectWorldTemplateScreen templateScreen;
    RealmsSelectWorldTemplateScreen experienceScreen;
    RealmsSelectWorldTemplateScreen inspirationScreen;
    switch (this.selectedType) {
      case WORLD_TEMPLATE:
        return;
      case ADVENTUREMAP:
        Realms.setScreen(new RealmsResetNormalWorldScreen(this, this.title));
      case EXPERIENCE:
        Realms.setScreen(new RealmsSelectFileToUploadScreen(this.serverData.id, (this.slot != -1) ? this.slot : this.serverData.activeSlot, this));
      case INSPIRATION:
        screen = new RealmsSelectWorldTemplateScreen(this, null, RealmsServer.WorldType.ADVENTUREMAP, new WorldTemplatePaginatedList(this.adventuremaps));
        screen.setTitle(getLocalizedString("mco.reset.world.adventure"));
        Realms.setScreen(screen);
      case null:
        templateScreen = new RealmsSelectWorldTemplateScreen(this, null, RealmsServer.WorldType.NORMAL, new WorldTemplatePaginatedList(this.templates));
        templateScreen.setTitle(getLocalizedString("mco.reset.world.template"));
        Realms.setScreen(templateScreen);
      case null:
        experienceScreen = new RealmsSelectWorldTemplateScreen(this, null, RealmsServer.WorldType.EXPERIENCE, new WorldTemplatePaginatedList(this.experiences));
        experienceScreen.setTitle(getLocalizedString("mco.reset.world.experience"));
        Realms.setScreen(experienceScreen);
      case null:
        inspirationScreen = new RealmsSelectWorldTemplateScreen(this, null, RealmsServer.WorldType.INSPIRATION, new WorldTemplatePaginatedList(this.inspirations));
        inspirationScreen.setTitle(getLocalizedString("mco.reset.world.inspiration"));
        Realms.setScreen(inspirationScreen);
    } 
  }
  
  private int frame(int i) {
    return width() / 2 - 130 + (i - 1) * 100;
  }
  
  public void render(int xm, int ym, float a) {
    this.selectedType = ResetType.NONE;
    renderBackground();
    drawCenteredString(this.title, width() / 2, 7, 16777215);
    drawCenteredString(this.subtitle, width() / 2, 22, this.subtitleColor);
    drawFrame(frame(1), RealmsConstants.row(0) + 10, xm, ym, getLocalizedString("mco.reset.world.generate"), -1L, "realms:textures/gui/realms/new_world.png", ResetType.GENERATE);
    drawFrame(frame(2), RealmsConstants.row(0) + 10, xm, ym, getLocalizedString("mco.reset.world.upload"), -1L, "realms:textures/gui/realms/upload.png", ResetType.UPLOAD);
    drawFrame(frame(3), RealmsConstants.row(0) + 10, xm, ym, getLocalizedString("mco.reset.world.template"), -1L, "realms:textures/gui/realms/survival_spawn.png", ResetType.SURVIVAL_SPAWN);
    drawFrame(frame(1), RealmsConstants.row(6) + 20, xm, ym, getLocalizedString("mco.reset.world.adventure"), -1L, "realms:textures/gui/realms/adventure.png", ResetType.ADVENTURE);
    drawFrame(frame(2), RealmsConstants.row(6) + 20, xm, ym, getLocalizedString("mco.reset.world.experience"), -1L, "realms:textures/gui/realms/experience.png", ResetType.EXPERIENCE);
    drawFrame(frame(3), RealmsConstants.row(6) + 20, xm, ym, getLocalizedString("mco.reset.world.inspiration"), -1L, "realms:textures/gui/realms/inspiration.png", ResetType.INSPIRATION);
    super.render(xm, ym, a);
  }
  
  private void drawFrame(int x, int y, int xm, int ym, String text, long imageId, String image, ResetType resetType) {
    boolean hovered = false;
    if (xm >= x && xm <= x + 60 && ym >= y - 12 && ym <= y + 60) {
      hovered = true;
      this.selectedType = resetType;
    } 
    if (imageId == -1L) {
      bind(image);
    } else {
      RealmsTextureManager.bindWorldTemplate(String.valueOf(imageId), image);
    } 
    if (hovered) {
      GL11.glColor4f(0.56F, 0.56F, 0.56F, 1.0F);
    } else {
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    } 
    RealmsScreen.blit(x + 2, y + 2, 0.0F, 0.0F, 56, 56, 56.0F, 56.0F);
    bind("realms:textures/gui/realms/slot_frame.png");
    if (hovered) {
      GL11.glColor4f(0.56F, 0.56F, 0.56F, 1.0F);
    } else {
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    } 
    RealmsScreen.blit(x, y, 0.0F, 0.0F, 60, 60, 60.0F, 60.0F);
    drawCenteredString(text, x + 30, y - 12, hovered ? 10526880 : 16777215);
  }
  
  void callback(WorldTemplate worldTemplate) {
    if (worldTemplate != null)
      if (this.slot == -1) {
        resetWorldWithTemplate(worldTemplate);
      } else {
        switch (worldTemplate.type) {
          case WORLD_TEMPLATE:
            this.typeToReset = ResetType.SURVIVAL_SPAWN;
            break;
          case ADVENTUREMAP:
            this.typeToReset = ResetType.ADVENTURE;
            break;
          case EXPERIENCE:
            this.typeToReset = ResetType.EXPERIENCE;
            break;
          case INSPIRATION:
            this.typeToReset = ResetType.INSPIRATION;
            break;
        } 
        this.worldTemplateToReset = worldTemplate;
        switchSlot();
      }  
  }
  
  private void switchSlot() {
    switchSlot(this);
  }
  
  public void switchSlot(RealmsScreen screen) {
    RealmsTasks.SwitchSlotTask switchSlotTask = new RealmsTasks.SwitchSlotTask(this.serverData.id, this.slot, screen, 100);
    RealmsLongRunningMcoTaskScreen longRunningMcoTaskScreen = new RealmsLongRunningMcoTaskScreen(this.lastScreen, (LongRunningTask)switchSlotTask);
    longRunningMcoTaskScreen.start();
    Realms.setScreen(longRunningMcoTaskScreen);
  }
  
  enum ResetType {
    NONE, GENERATE, UPLOAD, ADVENTURE, SURVIVAL_SPAWN, EXPERIENCE, INSPIRATION;
  }
  
  public void confirmResult(boolean result, int id) {
    if (id == 100 && result) {
      switch (this.typeToReset) {
        case INSPIRATION:
        case null:
        case null:
        case null:
          if (this.worldTemplateToReset != null)
            resetWorldWithTemplate(this.worldTemplateToReset); 
          return;
        case ADVENTUREMAP:
          if (this.worldInfoToReset != null)
            triggerResetWorld(this.worldInfoToReset); 
          return;
      } 
      return;
    } 
    if (result) {
      Realms.setScreen(this.returnScreen);
      if (this.confirmationId != -1)
        this.returnScreen.confirmResult(true, this.confirmationId); 
    } 
  }
  
  public void resetWorldWithTemplate(WorldTemplate template) {
    RealmsTasks.ResettingWorldTask resettingWorldTask = new RealmsTasks.ResettingWorldTask(this.serverData.id, this.returnScreen, template);
    if (this.resetTitle != null)
      resettingWorldTask.setResetTitle(this.resetTitle); 
    if (this.confirmationId != -1)
      resettingWorldTask.setConfirmationId(this.confirmationId); 
    RealmsLongRunningMcoTaskScreen longRunningMcoTaskScreen = new RealmsLongRunningMcoTaskScreen(this.lastScreen, (LongRunningTask)resettingWorldTask);
    longRunningMcoTaskScreen.start();
    Realms.setScreen(longRunningMcoTaskScreen);
  }
  
  public static class ResetWorldInfo {
    String seed;
    
    int levelType;
    
    boolean generateStructures;
    
    public ResetWorldInfo(String seed, int levelType, boolean generateStructures) {
      this.seed = seed;
      this.levelType = levelType;
      this.generateStructures = generateStructures;
    }
  }
  
  public void resetWorld(ResetWorldInfo resetWorldInfo) {
    if (this.slot == -1) {
      triggerResetWorld(resetWorldInfo);
    } else {
      this.typeToReset = ResetType.GENERATE;
      this.worldInfoToReset = resetWorldInfo;
      switchSlot();
    } 
  }
  
  private void triggerResetWorld(ResetWorldInfo resetWorldInfo) {
    RealmsTasks.ResettingWorldTask resettingWorldTask = new RealmsTasks.ResettingWorldTask(this.serverData.id, this.returnScreen, resetWorldInfo.seed, resetWorldInfo.levelType, resetWorldInfo.generateStructures);
    if (this.resetTitle != null)
      resettingWorldTask.setResetTitle(this.resetTitle); 
    if (this.confirmationId != -1)
      resettingWorldTask.setConfirmationId(this.confirmationId); 
    RealmsLongRunningMcoTaskScreen longRunningMcoTaskScreen = new RealmsLongRunningMcoTaskScreen(this.lastScreen, (LongRunningTask)resettingWorldTask);
    longRunningMcoTaskScreen.start();
    Realms.setScreen(longRunningMcoTaskScreen);
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\mojang\realms\1.10.22\realms-1.10.22.jar!\com\mojang\realmsclient\gui\screens\RealmsResetWorldScreen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */