package com.mojang.realmsclient.util;

import java.util.HashMap;
import java.util.Map;

public class UploadTokenCache {
  private static final Map<Long, String> tokenCache = new HashMap<>();
  
  public static String get(long worldId) {
    return tokenCache.get(Long.valueOf(worldId));
  }
  
  public static void invalidate(long world) {
    tokenCache.remove(Long.valueOf(world));
  }
  
  public static void put(long wid, String token) {
    tokenCache.put(Long.valueOf(wid), token);
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\mojang\realms\1.10.22\realms-1.10.22.jar!\com\mojang\realmsclien\\util\UploadTokenCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */