package com.mojang.realmsclient.client;

import java.net.Proxy;

public class RealmsClientConfig {
  private static Proxy proxy;
  
  public static Proxy getProxy() {
    return proxy;
  }
  
  public static void setProxy(Proxy proxy) {
    if (RealmsClientConfig.proxy == null)
      RealmsClientConfig.proxy = proxy; 
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\mojang\realms\1.10.22\realms-1.10.22.jar!\com\mojang\realmsclient\client\RealmsClientConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */