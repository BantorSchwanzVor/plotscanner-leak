package com.mojang.realmsclient.gui.screens;

import com.mojang.realmsclient.RealmsMainScreen;
import com.mojang.realmsclient.client.RealmsClient;
import com.mojang.realmsclient.dto.RealmsServer;
import com.mojang.realmsclient.exception.RealmsServiceException;
import com.mojang.realmsclient.gui.LongRunningTask;
import com.mojang.realmsclient.gui.RealmsConstants;
import com.mojang.realmsclient.util.RealmsTasks;
import com.mojang.realmsclient.util.RealmsUtil;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.util.concurrent.locks.ReentrantLock;
import net.minecraft.realms.Realms;
import net.minecraft.realms.RealmsButton;
import net.minecraft.realms.RealmsScreen;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.input.Keyboard;

public class RealmsTermsScreen extends RealmsScreen {
  private static final Logger LOGGER = LogManager.getLogger();
  
  private static final int BUTTON_AGREE_ID = 1;
  
  private static final int BUTTON_DISAGREE_ID = 2;
  
  private final RealmsScreen lastScreen;
  
  private final RealmsMainScreen mainScreen;
  
  private final RealmsServer realmsServer;
  
  private RealmsButton agreeButton;
  
  private boolean onLink;
  
  private final String realmsToSUrl = "https://minecraft.net/realms/terms";
  
  public RealmsTermsScreen(RealmsScreen lastScreen, RealmsMainScreen mainScreen, RealmsServer realmsServer) {
    this.lastScreen = lastScreen;
    this.mainScreen = mainScreen;
    this.realmsServer = realmsServer;
  }
  
  public void init() {
    Keyboard.enableRepeatEvents(true);
    buttonsClear();
    int column1X = width() / 4;
    int columnWidth = width() / 4 - 2;
    int column2X = width() / 2 + 4;
    buttonsAdd(this.agreeButton = newButton(1, column1X, RealmsConstants.row(12), columnWidth, 20, getLocalizedString("mco.terms.buttons.agree")));
    buttonsAdd(newButton(2, column2X, RealmsConstants.row(12), columnWidth, 20, getLocalizedString("mco.terms.buttons.disagree")));
  }
  
  public void removed() {
    Keyboard.enableRepeatEvents(false);
  }
  
  public void buttonClicked(RealmsButton button) {
    if (!button.active())
      return; 
    switch (button.id()) {
      case 2:
        Realms.setScreen(this.lastScreen);
        return;
      case 1:
        agreedToTos();
        return;
    } 
  }
  
  public void keyPressed(char eventCharacter, int eventKey) {
    if (eventKey == 1)
      Realms.setScreen(this.lastScreen); 
  }
  
  private void agreedToTos() {
    RealmsClient client = RealmsClient.createRealmsClient();
    try {
      client.agreeToTos();
      RealmsLongRunningMcoTaskScreen longRunningMcoTaskScreen = new RealmsLongRunningMcoTaskScreen(this.lastScreen, (LongRunningTask)new RealmsTasks.RealmsGetServerDetailsTask(this.mainScreen, this.lastScreen, this.realmsServer, new ReentrantLock()));
      longRunningMcoTaskScreen.start();
      Realms.setScreen(longRunningMcoTaskScreen);
    } catch (RealmsServiceException ignored) {
      LOGGER.error("Couldn't agree to TOS");
    } 
  }
  
  public void mouseClicked(int x, int y, int buttonNum) {
    super.mouseClicked(x, y, buttonNum);
    if (this.onLink) {
      Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
      clipboard.setContents(new StringSelection("https://minecraft.net/realms/terms"), null);
      RealmsUtil.browseTo("https://minecraft.net/realms/terms");
    } 
  }
  
  public void render(int xm, int ym, float a) {
    renderBackground();
    drawCenteredString(getLocalizedString("mco.terms.title"), width() / 2, 17, 16777215);
    drawString(getLocalizedString("mco.terms.sentence.1"), width() / 2 - 120, RealmsConstants.row(5), 16777215);
    int firstPartWidth = fontWidth(getLocalizedString("mco.terms.sentence.1"));
    int x1 = width() / 2 - 121 + firstPartWidth;
    int y1 = RealmsConstants.row(5);
    int x2 = x1 + fontWidth("mco.terms.sentence.2") + 1;
    int y2 = y1 + 1 + fontLineHeight();
    if (x1 <= xm && xm <= x2 && y1 <= ym && ym <= y2) {
      this.onLink = true;
      drawString(" " + getLocalizedString("mco.terms.sentence.2"), width() / 2 - 120 + firstPartWidth, RealmsConstants.row(5), 7107012);
    } else {
      this.onLink = false;
      drawString(" " + getLocalizedString("mco.terms.sentence.2"), width() / 2 - 120 + firstPartWidth, RealmsConstants.row(5), 3368635);
    } 
    super.render(xm, ym, a);
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\mojang\realms\1.10.22\realms-1.10.22.jar!\com\mojang\realmsclient\gui\screens\RealmsTermsScreen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */