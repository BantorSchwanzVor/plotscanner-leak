package com.mojang.realmsclient.dto;

public class RegionPingResult {
  private final String regionName;
  
  private final int ping;
  
  public RegionPingResult(String regionName, int ping) {
    this.regionName = regionName;
    this.ping = ping;
  }
  
  public int ping() {
    return this.ping;
  }
  
  public String toString() {
    return String.format("%s --> %.2f ms", new Object[] { this.regionName, Integer.valueOf(this.ping) });
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\mojang\realms\1.10.22\realms-1.10.22.jar!\com\mojang\realmsclient\dto\RegionPingResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */