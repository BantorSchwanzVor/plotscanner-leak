package com.mojang.realmsclient.dto;

import java.util.ArrayList;
import java.util.List;

public class PingResult {
  public List<RegionPingResult> pingResults = new ArrayList<>();
  
  public List<Long> worldIds = new ArrayList<>();
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\mojang\realms\1.10.22\realms-1.10.22.jar!\com\mojang\realmsclient\dto\PingResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */