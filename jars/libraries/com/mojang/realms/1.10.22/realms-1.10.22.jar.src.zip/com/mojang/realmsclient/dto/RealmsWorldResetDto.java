package com.mojang.realmsclient.dto;

public class RealmsWorldResetDto {
  private final String seed;
  
  private final long worldTemplateId;
  
  private final int levelType;
  
  private final boolean generateStructures;
  
  public RealmsWorldResetDto(String seed, long worldTemplateId, int levelType, boolean generateStructures) {
    this.seed = seed;
    this.worldTemplateId = worldTemplateId;
    this.levelType = levelType;
    this.generateStructures = generateStructures;
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\mojang\realms\1.10.22\realms-1.10.22.jar!\com\mojang\realmsclient\dto\RealmsWorldResetDto.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */