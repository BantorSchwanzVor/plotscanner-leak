package com.mojang.text2speech;

public class Text2Speech {
  public static void main(String[] args) {
    System.setProperty("jna.library.path", "./src/natives/resources/");
    Narrator narrator = Narrator.getNarrator();
    narrator.say("This is a test");
    while (true) {
      try {
        while (true)
          Thread.sleep(100L); 
        break;
      } catch (InterruptedException e) {
        e.printStackTrace();
      } 
    } 
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\mojang\text2speech\1.10.3\text2speech-1.10.3.jar!\com\mojang\text2speech\Text2Speech.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */