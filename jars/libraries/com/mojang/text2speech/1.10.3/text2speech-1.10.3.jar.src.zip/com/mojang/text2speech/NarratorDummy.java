package com.mojang.text2speech;

public class NarratorDummy implements Narrator {
  public void say(String msg) {}
  
  public void clear() {}
  
  public boolean active() {
    return false;
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\mojang\text2speech\1.10.3\text2speech-1.10.3.jar!\com\mojang\text2speech\NarratorDummy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */