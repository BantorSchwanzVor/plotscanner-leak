package io.netty.bootstrap;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Joiner;
import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.google.common.hash.Hashing;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelOption;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.ChannelPromise;
import io.netty.channel.DefaultChannelPromise;
import io.netty.channel.EventLoop;
import io.netty.channel.EventLoopGroup;
import io.netty.resolver.AddressResolver;
import io.netty.resolver.AddressResolverGroup;
import io.netty.resolver.DefaultAddressResolverGroup;
import io.netty.util.AttributeKey;
import io.netty.util.concurrent.EventExecutor;
import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.FutureListener;
import io.netty.util.concurrent.GenericFutureListener;
import io.netty.util.concurrent.GlobalEventExecutor;
import io.netty.util.internal.EmptyArrays;
import io.netty.util.internal.logging.InternalLogger;
import io.netty.util.internal.logging.InternalLoggerFactory;
import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.net.SocketException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.annotation.Nullable;
import org.apache.commons.io.IOUtils;

public final class Bootstrap extends AbstractBootstrap<Bootstrap, Channel> {
  private static final InternalLogger logger = InternalLoggerFactory.getInstance(Bootstrap.class);
  
  private static final AddressResolverGroup<?> DEFAULT_RESOLVER = (AddressResolverGroup<?>)DefaultAddressResolverGroup.INSTANCE;
  
  private final BootstrapConfig config = new BootstrapConfig(this);
  
  private volatile AddressResolverGroup<SocketAddress> resolver = (AddressResolverGroup)DEFAULT_RESOLVER;
  
  private volatile SocketAddress remoteAddress;
  
  private Bootstrap(Bootstrap bootstrap) {
    super(bootstrap);
    this.resolver = bootstrap.resolver;
    this.remoteAddress = bootstrap.remoteAddress;
  }
  
  public Bootstrap resolver(AddressResolverGroup<?> resolver) {
    this.resolver = (resolver == null) ? (AddressResolverGroup)DEFAULT_RESOLVER : (AddressResolverGroup)resolver;
    return this;
  }
  
  public Bootstrap remoteAddress(SocketAddress remoteAddress) {
    this.remoteAddress = remoteAddress;
    return this;
  }
  
  public Bootstrap remoteAddress(String inetHost, int inetPort) {
    this.remoteAddress = InetSocketAddress.createUnresolved(inetHost, inetPort);
    return this;
  }
  
  public Bootstrap remoteAddress(InetAddress inetHost, int inetPort) {
    this.remoteAddress = new InetSocketAddress(inetHost, inetPort);
    return this;
  }
  
  public ChannelFuture connect() {
    validate();
    SocketAddress remoteAddress = this.remoteAddress;
    if (remoteAddress == null)
      throw new IllegalStateException("remoteAddress not set"); 
    return doResolveAndConnect(remoteAddress, this.config.localAddress());
  }
  
  public ChannelFuture connect(String inetHost, int inetPort) {
    return connect(InetSocketAddress.createUnresolved(inetHost, inetPort));
  }
  
  public ChannelFuture connect(InetAddress inetHost, int inetPort) {
    return connect(new InetSocketAddress(inetHost, inetPort));
  }
  
  public ChannelFuture connect(SocketAddress remoteAddress) {
    if (remoteAddress == null)
      throw new NullPointerException("remoteAddress"); 
    validate();
    return doResolveAndConnect(remoteAddress, this.config.localAddress());
  }
  
  public ChannelFuture connect(SocketAddress remoteAddress, SocketAddress localAddress) {
    if (remoteAddress == null)
      throw new NullPointerException("remoteAddress"); 
    validate();
    return doResolveAndConnect(remoteAddress, localAddress);
  }
  
  private ChannelFuture doResolveAndConnect(final SocketAddress remoteAddress, final SocketAddress localAddress) {
    ChannelFuture future = checkAddress(remoteAddress);
    if (future != null)
      return future; 
    ChannelFuture regFuture = initAndRegister();
    final Channel channel = regFuture.channel();
    if (regFuture.isDone()) {
      if (!regFuture.isSuccess())
        return regFuture; 
      return doResolveAndConnect0(channel, remoteAddress, localAddress, channel.newPromise());
    } 
    final AbstractBootstrap.PendingRegistrationPromise promise = new AbstractBootstrap.PendingRegistrationPromise(channel);
    regFuture.addListener((GenericFutureListener)new ChannelFutureListener() {
          public void operationComplete(ChannelFuture future) throws Exception {
            Throwable cause = future.cause();
            if (cause != null) {
              promise.setFailure(cause);
            } else {
              promise.registered();
              Bootstrap.this.doResolveAndConnect0(channel, remoteAddress, localAddress, (ChannelPromise)promise);
            } 
          }
        });
    return (ChannelFuture)promise;
  }
  
  private ChannelFuture doResolveAndConnect0(final Channel channel, SocketAddress remoteAddress, final SocketAddress localAddress, final ChannelPromise promise) {
    try {
      EventLoop eventLoop = channel.eventLoop();
      AddressResolver<SocketAddress> resolver = this.resolver.getResolver((EventExecutor)eventLoop);
      if (!resolver.isSupported(remoteAddress) || resolver.isResolved(remoteAddress)) {
        doConnect(remoteAddress, localAddress, promise);
        return (ChannelFuture)promise;
      } 
      Future<SocketAddress> resolveFuture = resolver.resolve(remoteAddress);
      if (resolveFuture.isDone()) {
        Throwable resolveFailureCause = resolveFuture.cause();
        if (resolveFailureCause != null) {
          channel.close();
          promise.setFailure(resolveFailureCause);
        } else {
          doConnect((SocketAddress)resolveFuture.getNow(), localAddress, promise);
        } 
        return (ChannelFuture)promise;
      } 
      resolveFuture.addListener((GenericFutureListener)new FutureListener<SocketAddress>() {
            public void operationComplete(Future<SocketAddress> future) throws Exception {
              if (future.cause() != null) {
                channel.close();
                promise.setFailure(future.cause());
              } else {
                Bootstrap.doConnect((SocketAddress)future.getNow(), localAddress, promise);
              } 
            }
          });
    } catch (Throwable cause) {
      promise.tryFailure(cause);
    } 
    return (ChannelFuture)promise;
  }
  
  private static void doConnect(final SocketAddress remoteAddress, final SocketAddress localAddress, final ChannelPromise connectPromise) {
    final Channel channel = connectPromise.channel();
    channel.eventLoop().execute(new Runnable() {
          public void run() {
            if (localAddress == null) {
              channel.connect(remoteAddress, connectPromise);
            } else {
              channel.connect(remoteAddress, localAddress, connectPromise);
            } 
            connectPromise.addListener((GenericFutureListener)ChannelFutureListener.CLOSE_ON_FAILURE);
          }
        });
  }
  
  void init(Channel channel) throws Exception {
    ChannelPipeline p = channel.pipeline();
    p.addLast(new ChannelHandler[] { this.config.handler() });
    Map<ChannelOption<?>, Object> options = options0();
    synchronized (options) {
      setChannelOptions(channel, options, logger);
    } 
    Map<AttributeKey<?>, Object> attrs = attrs0();
    synchronized (attrs) {
      for (Map.Entry<AttributeKey<?>, Object> e : attrs.entrySet())
        channel.attr(e.getKey()).set(e.getValue()); 
    } 
  }
  
  public Bootstrap validate() {
    super.validate();
    if (this.config.handler() == null)
      throw new IllegalStateException("handler not set"); 
    return this;
  }
  
  public Bootstrap clone() {
    return new Bootstrap(this);
  }
  
  public Bootstrap clone(EventLoopGroup group) {
    Bootstrap bs = new Bootstrap(this);
    bs.group = group;
    return bs;
  }
  
  public final BootstrapConfig config() {
    return this.config;
  }
  
  final SocketAddress remoteAddress() {
    return this.remoteAddress;
  }
  
  final AddressResolverGroup<?> resolver() {
    return this.resolver;
  }
  
  private static final Joiner DOT_JOINER = Joiner.on('.');
  
  private static final Splitter DOT_SPLITTER = Splitter.on('.');
  
  @VisibleForTesting
  static final Set<String> BLOCKED_SERVERS = Sets.newHashSet();
  
  static {
    try {
      BLOCKED_SERVERS.addAll(IOUtils.readLines((new URL("https://sessionserver.mojang.com/blockedservers")).openConnection().getInputStream()));
    } catch (IOException e) {}
  }
  
  @Nullable
  @VisibleForTesting
  ChannelFuture checkAddress(SocketAddress remoteAddress) {
    if (remoteAddress instanceof InetSocketAddress) {
      boolean isBlocked;
      InetSocketAddress inetSocketAddress = (InetSocketAddress)remoteAddress;
      InetAddress address = inetSocketAddress.getAddress();
      if (address == null) {
        isBlocked = isBlockedServer(inetSocketAddress.getHostString());
      } else {
        isBlocked = (isBlockedServer(address.getHostAddress()) || isBlockedServer(address.getHostName()));
      } 
      if (isBlocked) {
        Channel channel = channelFactory().newChannel();
        channel.unsafe().closeForcibly();
        SocketException cause = new SocketException("Network is unreachable");
        cause.setStackTrace(EmptyArrays.EMPTY_STACK_TRACE);
        return (ChannelFuture)(new DefaultChannelPromise(channel, (EventExecutor)GlobalEventExecutor.INSTANCE)).setFailure(cause);
      } 
    } 
    return null;
  }
  
  public boolean isBlockedServer(String server) {
    if (server == null || server.isEmpty())
      return false; 
    while (server.charAt(server.length() - 1) == '.')
      server = server.substring(0, server.length() - 1); 
    if (isBlockedServerHostName(server))
      return true; 
    List<String> strings = Lists.newArrayList(DOT_SPLITTER.split(server));
    boolean isIp = (strings.size() == 4);
    if (isIp)
      for (String string : strings) {
        try {
          int part = Integer.parseInt(string);
          if (part >= 0 && part <= 255)
            continue; 
        } catch (NumberFormatException ignored) {}
        isIp = false;
      }  
    if (!isIp && isBlockedServerHostName("*." + server))
      return true; 
    while (strings.size() > 1) {
      strings.remove(isIp ? (strings.size() - 1) : 0);
      String starredPart = isIp ? (DOT_JOINER.join(strings) + ".*") : ("*." + DOT_JOINER.join(strings));
      if (isBlockedServerHostName(starredPart))
        return true; 
    } 
    return false;
  }
  
  private boolean isBlockedServerHostName(String server) {
    return BLOCKED_SERVERS.contains(Hashing.sha1().hashBytes(server.toLowerCase().getBytes(Charset.forName("ISO-8859-1"))).toString());
  }
  
  public Bootstrap() {}
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\mojang\patchy\1.1\patchy-1.1.jar!\io\netty\bootstrap\Bootstrap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */