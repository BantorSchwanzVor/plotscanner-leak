package paulscode.sound;

public interface IStreamListener {
  void endOfStream(String paramString, int paramInt);
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\paulscode\soundsystem\20120107\soundsystem-20120107.jar!\paulscode\sound\IStreamListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */