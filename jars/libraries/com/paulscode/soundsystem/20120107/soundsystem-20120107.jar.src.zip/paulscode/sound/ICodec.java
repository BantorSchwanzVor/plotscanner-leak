package paulscode.sound;

import java.net.URL;
import javax.sound.sampled.AudioFormat;

public interface ICodec {
  void reverseByteOrder(boolean paramBoolean);
  
  boolean initialize(URL paramURL);
  
  boolean initialized();
  
  SoundBuffer read();
  
  SoundBuffer readAll();
  
  boolean endOfStream();
  
  void cleanup();
  
  AudioFormat getAudioFormat();
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\paulscode\soundsystem\20120107\soundsystem-20120107.jar!\paulscode\sound\ICodec.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */