package com.jcraft.jogg;

public class Packet {
  public byte[] packet_base;
  
  public int packet;
  
  public int bytes;
  
  public int b_o_s;
  
  public int e_o_s;
  
  public long granulepos;
  
  public long packetno;
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\paulscode\codecjorbis\20101023\codecjorbis-20101023.jar!\com\jcraft\jogg\Packet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */