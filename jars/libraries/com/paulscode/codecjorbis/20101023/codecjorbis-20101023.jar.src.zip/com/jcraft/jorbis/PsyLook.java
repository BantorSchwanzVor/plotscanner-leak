package com.jcraft.jorbis;

class PsyLook {
  int n;
  
  PsyInfo vi;
  
  float[][][] tonecurves;
  
  float[][] peakatt;
  
  float[][][] noisecurves;
  
  float[] ath;
  
  int[] octave;
  
  void init(PsyInfo vi, int n, int rate) {}
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\paulscode\codecjorbis\20101023\codecjorbis-20101023.jar!\com\jcraft\jorbis\PsyLook.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */