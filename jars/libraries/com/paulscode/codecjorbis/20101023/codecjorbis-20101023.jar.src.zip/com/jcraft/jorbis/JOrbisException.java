package com.jcraft.jorbis;

public class JOrbisException extends Exception {
  private static final long serialVersionUID = 1L;
  
  public JOrbisException() {}
  
  public JOrbisException(String s) {
    super("JOrbis: " + s);
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\paulscode\codecjorbis\20101023\codecjorbis-20101023.jar!\com\jcraft\jorbis\JOrbisException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */