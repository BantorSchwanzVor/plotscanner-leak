package com.jcraft.jorbis;

class InfoMode {
  int blockflag;
  
  int windowtype;
  
  int transformtype;
  
  int mapping;
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\com\paulscode\codecjorbis\20101023\codecjorbis-20101023.jar!\com\jcraft\jorbis\InfoMode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */