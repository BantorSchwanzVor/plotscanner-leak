/* Copyright (C) 1991-2016 Free Software Foundation, Inc.
   This file is part of the GNU C Library.

   The GNU C Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with the GNU C Library; if not, see
   <http://www.gnu.org/licenses/>.  */
/* This header is separate from features.h so that the compiler can
   include it implicitly at the start of every compilation.  It must
   not itself include <features.h> or any other header that includes
   <features.h> because the implicit include comes before any feature
   test macros that may be defined in a source file before it first
   explicitly includes a system header.  GCC knows the name of this
   header in order to preinclude it.  */
/* glibc's intent is to support the IEC 559 math functionality, real
   and complex.  If the GCC (4.9 and later) predefined macros
   specifying compiler intent are available, use them to determine
   whether the overall intent is to support these features; otherwise,
   presume an older compiler has intent to support these features and
   define these macros by default.  */
/* wchar_t uses Unicode 9.0.0.  Version 9.0 of the Unicode Standard is
   synchronized with ISO/IEC 10646:2014, fourth edition, plus
   Amd. 1  and Amd. 2 and 273 characters from forthcoming  10646, fifth edition.
   (Amd. 2 was published 2016-05-01,
   see https://www.iso.org/obp/ui/#iso:std:iso-iec:10646:ed-4:v1:amd:2:v1:en) */
/* We do not support C11 <threads.h>.  */
/* Generic definitions */
/* Assertions (useful to generate conditional code) */
/* Current type and class (and size, if applicable) */
/* Value methods */
/* Interfaces (keys) */
/* Interfaces (values) */
/* Abstract implementations (keys) */
/* Abstract implementations (values) */
/* Static containers (keys) */
/* Static containers (values) */
/* Implementations */
/* Synchronized wrappers */
/* Unmodifiable wrappers */
/* Other wrappers */
/* Methods (keys) */
/* Methods (values) */
/* Methods (keys/values) */
/* Methods that have special names depending on keys (but the special names depend on values) */
/* Equality */
/* Object/Reference-only definitions (keys) */
/* Primitive-type-only definitions (keys) */
/* Object/Reference-only definitions (values) */
/*		 
 * Copyright (C) 2003-2016 Paolo Boldi and Sebastiano Vigna
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License. 
 */
package it.unimi.dsi.fastutil.bytes;

import java.util.Arrays;

/**
 * A class providing static methods and objects that do useful things with
 * indirect heaps.
 *
 * <P>
 * An indirect heap is an extension of a semi-indirect heap using also an
 * <em>inversion array</em> of the same length as the reference array,
 * satisfying the relation <code>heap[inv[i]]==i</code> when
 * <code>inv[i]&gt;=0</code>, and <code>inv[heap[i]]==i</code> for all elements
 * in the heap.
 */
public class ByteIndirectHeaps {
	private ByteIndirectHeaps() {
	}

	/**
	 * Moves the given element down into the indirect heap until it reaches the
	 * lowest possible position.
	 *
	 * @param refArray
	 *            the reference array.
	 * @param heap
	 *            the indirect heap (starting at 0).
	 * @param inv
	 *            the inversion array.
	 * @param size
	 *            the number of elements in the heap.
	 * @param i
	 *            the index in the heap of the element to be moved down.
	 * @param c
	 *            a type-specific comparator, or <code>null</code> for the
	 *            natural order.
	 * @return the new position in the heap of the element of heap index
	 *         <code>i</code>.
	 */

	public static int downHeap(final byte[] refArray, final int[] heap, final int[] inv, final int size, int i, final ByteComparator c) {
		assert i < size;
		final int e = heap[i];
		final byte E = refArray[e];
		int child;
		if (c == null) while ((child = (i << 1) + 1) < size) {
			int t = heap[child];
			final int right = child + 1;
			if (right < size && ((refArray[heap[right]]) < (refArray[t]))) t = heap[child = right];
			if (((E) <= (refArray[t]))) break;
			heap[i] = t;
			inv[heap[i]] = i;
			i = child;
		}
		else while ((child = (i << 1) + 1) < size) {
			int t = heap[child];
			final int right = child + 1;
			if (right < size && c.compare(refArray[heap[right]], refArray[t]) < 0) t = heap[child = right];
			if (c.compare(E, refArray[t]) <= 0) break;
			heap[i] = t;
			inv[heap[i]] = i;
			i = child;
		}
		heap[i] = e;
		inv[e] = i;
		return i;
	}

	/**
	 * Moves the given element up in the indirect heap until it reaches the
	 * highest possible position.
	 *
	 * Note that in principle after this call the heap property may be violated.
	 * 
	 * @param refArray
	 *            the reference array.
	 * @param heap
	 *            the indirect heap (starting at 0).
	 * @param inv
	 *            the inversion array.
	 * @param size
	 *            the number of elements in the heap.
	 * @param i
	 *            the index in the heap of the element to be moved up.
	 * @param c
	 *            a type-specific comparator, or <code>null</code> for the
	 *            natural order.
	 * @return the new position in the heap of the element of heap index
	 *         <code>i</code>.
	 */

	public static int upHeap(final byte[] refArray, final int[] heap, final int[] inv, final int size, int i, final ByteComparator c) {
		assert i < size;
		final int e = heap[i];
		final byte E = refArray[e];
		if (c == null) while (i != 0) {
			final int parent = (i - 1) >>> 1;
			final int t = heap[parent];
			if (((refArray[t]) <= (E))) break;
			heap[i] = t;
			inv[heap[i]] = i;
			i = parent;
		}
		else while (i != 0) {
			final int parent = (i - 1) >>> 1;
			final int t = heap[parent];
			if (c.compare(refArray[t], E) <= 0) break;
			heap[i] = t;
			inv[heap[i]] = i;
			i = parent;
		}
		heap[i] = e;
		inv[e] = i;
		return i;
	}

	/**
	 * Creates an indirect heap in the given array.
	 *
	 * @param refArray
	 *            the reference array.
	 * @param offset
	 *            the first element of the reference array to be put in the
	 *            heap.
	 * @param length
	 *            the number of elements to be put in the heap.
	 * @param heap
	 *            the array where the heap is to be created.
	 * @param inv
	 *            the inversion array.
	 * @param c
	 *            a type-specific comparator, or <code>null</code> for the
	 *            natural order.
	 */
	public static void makeHeap(final byte[] refArray, final int offset, final int length, final int[] heap, final int[] inv, final ByteComparator c) {
		ByteArrays.ensureOffsetLength(refArray, offset, length);
		if (heap.length < length) throw new IllegalArgumentException("The heap length (" + heap.length + ") is smaller than the number of elements (" + length + ")");
		if (inv.length < refArray.length) throw new IllegalArgumentException("The inversion array length (" + heap.length + ") is smaller than the length of the reference array (" + refArray.length + ")");
		Arrays.fill(inv, 0, refArray.length, -1);
		int i = length;
		while (i-- != 0)
			inv[heap[i] = offset + i] = i;
		i = length >>> 1;
		while (i-- != 0)
			downHeap(refArray, heap, inv, length, i, c);
	}

	/**
	 * Creates an indirect heap from a given index array.
	 *
	 * @param refArray
	 *            the reference array.
	 * @param heap
	 *            an array containing indices into <code>refArray</code>.
	 * @param inv
	 *            the inversion array.
	 * @param size
	 *            the number of elements in the heap.
	 * @param c
	 *            a type-specific comparator, or <code>null</code> for the
	 *            natural order.
	 */
	public static void makeHeap(final byte[] refArray, final int[] heap, final int[] inv, final int size, final ByteComparator c) {
		int i = size >>> 1;
		while (i-- != 0)
			downHeap(refArray, heap, inv, size, i, c);
	}
}
