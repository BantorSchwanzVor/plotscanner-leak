/* Copyright (C) 1991-2016 Free Software Foundation, Inc.
   This file is part of the GNU C Library.

   The GNU C Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with the GNU C Library; if not, see
   <http://www.gnu.org/licenses/>.  */
/* This header is separate from features.h so that the compiler can
   include it implicitly at the start of every compilation.  It must
   not itself include <features.h> or any other header that includes
   <features.h> because the implicit include comes before any feature
   test macros that may be defined in a source file before it first
   explicitly includes a system header.  GCC knows the name of this
   header in order to preinclude it.  */
/* glibc's intent is to support the IEC 559 math functionality, real
   and complex.  If the GCC (4.9 and later) predefined macros
   specifying compiler intent are available, use them to determine
   whether the overall intent is to support these features; otherwise,
   presume an older compiler has intent to support these features and
   define these macros by default.  */
/* wchar_t uses Unicode 9.0.0.  Version 9.0 of the Unicode Standard is
   synchronized with ISO/IEC 10646:2014, fourth edition, plus
   Amd. 1  and Amd. 2 and 273 characters from forthcoming  10646, fifth edition.
   (Amd. 2 was published 2016-05-01,
   see https://www.iso.org/obp/ui/#iso:std:iso-iec:10646:ed-4:v1:amd:2:v1:en) */
/* We do not support C11 <threads.h>.  */
/* Generic definitions */
/* Assertions (useful to generate conditional code) */
/* Current type and class (and size, if applicable) */
/* Value methods */
/* Interfaces (keys) */
/* Interfaces (values) */
/* Abstract implementations (keys) */
/* Abstract implementations (values) */
/* Static containers (keys) */
/* Static containers (values) */
/* Implementations */
/* Synchronized wrappers */
/* Unmodifiable wrappers */
/* Other wrappers */
/* Methods (keys) */
/* Methods (values) */
/* Methods (keys/values) */
/* Methods that have special names depending on keys (but the special names depend on values) */
/* Equality */
/* Object/Reference-only definitions (keys) */
/* Primitive-type-only definitions (keys) */
/* Object/Reference-only definitions (values) */
/*		 
 * Copyright (C) 2003-2016 Paolo Boldi and Sebastiano Vigna
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License. 
 */
package it.unimi.dsi.fastutil.chars;

import java.util.Iterator;
import java.util.Collection;
import java.util.NoSuchElementException;

/**
 * A type-specific heap-based priority queue.
 *
 * <P>
 * Instances of this class represent a priority queue using a heap. The heap is
 * enlarged as needed, but it is never shrunk. Use the {@link #trim()} method to
 * reduce its size, if necessary.
 */
public class CharHeapPriorityQueue extends AbstractCharPriorityQueue implements java.io.Serializable {
	private static final long serialVersionUID = 1L;
	/** The heap array. */

	protected transient char[] heap = CharArrays.EMPTY_ARRAY;
	/** The number of elements in this queue. */
	protected int size;
	/** The type-specific comparator used in this queue. */
	protected CharComparator c;

	/**
	 * Creates a new empty queue with a given capacity and comparator.
	 *
	 * @param capacity
	 *            the initial capacity of this queue.
	 * @param c
	 *            the comparator used in this queue, or <code>null</code> for
	 *            the natural order.
	 */

	public CharHeapPriorityQueue(int capacity, CharComparator c) {
		if (capacity > 0) this.heap = new char[capacity];
		this.c = c;
	}

	/**
	 * Creates a new empty queue with a given capacity and using the natural
	 * order.
	 *
	 * @param capacity
	 *            the initial capacity of this queue.
	 */
	public CharHeapPriorityQueue(int capacity) {
		this(capacity, null);
	}

	/**
	 * Creates a new empty queue with a given comparator.
	 *
	 * @param c
	 *            the comparator used in this queue, or <code>null</code> for
	 *            the natural order.
	 */
	public CharHeapPriorityQueue(CharComparator c) {
		this(0, c);
	}

	/**
	 * Creates a new empty queue using the natural order.
	 */
	public CharHeapPriorityQueue() {
		this(0, null);
	}

	/**
	 * Wraps a given array in a queue using a given comparator.
	 *
	 * <P>
	 * The queue returned by this method will be backed by the given array. The
	 * first <code>size</code> element of the array will be rearranged so to
	 * form a heap (this is more efficient than enqueing the elements of
	 * <code>a</code> one by one).
	 *
	 * @param a
	 *            an array.
	 * @param size
	 *            the number of elements to be included in the queue.
	 * @param c
	 *            the comparator used in this queue, or <code>null</code> for
	 *            the natural order.
	 */
	public CharHeapPriorityQueue(final char[] a, int size, final CharComparator c) {
		this(c);
		this.heap = a;
		this.size = size;
		CharHeaps.makeHeap(a, size, c);
	}

	/**
	 * Wraps a given array in a queue using a given comparator.
	 *
	 * <P>
	 * The queue returned by this method will be backed by the given array. The
	 * elements of the array will be rearranged so to form a heap (this is more
	 * efficient than enqueing the elements of <code>a</code> one by one).
	 *
	 * @param a
	 *            an array.
	 * @param c
	 *            the comparator used in this queue, or <code>null</code> for
	 *            the natural order.
	 */
	public CharHeapPriorityQueue(final char[] a, final CharComparator c) {
		this(a, a.length, c);
	}

	/**
	 * Wraps a given array in a queue using the natural order.
	 *
	 * <P>
	 * The queue returned by this method will be backed by the given array. The
	 * first <code>size</code> element of the array will be rearranged so to
	 * form a heap (this is more efficient than enqueing the elements of
	 * <code>a</code> one by one).
	 *
	 * @param a
	 *            an array.
	 * @param size
	 *            the number of elements to be included in the queue.
	 */
	public CharHeapPriorityQueue(final char[] a, int size) {
		this(a, size, null);
	}

	/**
	 * Wraps a given array in a queue using the natural order.
	 *
	 * <P>
	 * The queue returned by this method will be backed by the given array. The
	 * elements of the array will be rearranged so to form a heap (this is more
	 * efficient than enqueing the elements of <code>a</code> one by one).
	 *
	 * @param a
	 *            an array.
	 */
	public CharHeapPriorityQueue(final char[] a) {
		this(a, a.length);
	}

	/**
	 * Creates a queue using the elements in a type-specific collection using a
	 * given comparator.
	 *
	 * <P>
	 * This constructor is more efficient than enqueing the elements of
	 * <code>collection</code> one by one.
	 *
	 * @param collection
	 *            a collection; its elements will be used to initialize the
	 *            queue.
	 * @param c
	 *            the comparator used in this queue, or <code>null</code> for
	 *            the natural order.
	 */
	public CharHeapPriorityQueue(final CharCollection collection, final CharComparator c) {
		this(collection.toCharArray(), c);
	}

	/**
	 * Creates a queue using the elements in a type-specific collection using
	 * the natural order.
	 *
	 * <P>
	 * This constructor is more efficient than enqueing the elements of
	 * <code>collection</code> one by one.
	 *
	 * @param collection
	 *            a collection; its elements will be used to initialize the
	 *            queue.
	 */
	public CharHeapPriorityQueue(final CharCollection collection) {
		this(collection, null);
	}

	/**
	 * Creates a queue using the elements in a collection using a given
	 * comparator.
	 *
	 * <P>
	 * This constructor is more efficient than enqueing the elements of
	 * <code>collection</code> one by one.
	 *
	 * @param collection
	 *            a collection; its elements will be used to initialize the
	 *            queue.
	 * @param c
	 *            the comparator used in this queue, or <code>null</code> for
	 *            the natural order.
	 */
	public CharHeapPriorityQueue(final Collection<? extends Character> collection, final CharComparator c) {
		this(collection.size(), c);
		final Iterator<? extends Character> iterator = collection.iterator();
		final int size = collection.size();
		for (int i = 0; i < size; i++)
			heap[i] = ((((Character) (iterator.next())).charValue()));
	}

	/**
	 * Creates a queue using the elements in a collection using the natural
	 * order.
	 *
	 * <P>
	 * This constructor is more efficient than enqueing the elements of
	 * <code>collection</code> one by one.
	 *
	 * @param collection
	 *            a collection; its elements will be used to initialize the
	 *            queue.
	 */
	public CharHeapPriorityQueue(final Collection<? extends Character> collection) {
		this(collection, null);
	}

	public void enqueue(char x) {
		if (size == heap.length) heap = CharArrays.grow(heap, size + 1);
		heap[size++] = x;
		CharHeaps.upHeap(heap, size, size - 1, c);
	}

	public char dequeueChar() {
		if (size == 0) throw new NoSuchElementException();
		final char result = heap[0];
		heap[0] = heap[--size];
		if (size != 0) CharHeaps.downHeap(heap, size, 0, c);
		return result;
	}

	public char firstChar() {
		if (size == 0) throw new NoSuchElementException();
		return heap[0];
	}

	public void changed() {
		CharHeaps.downHeap(heap, size, 0, c);
	}

	public int size() {
		return size;
	}

	public void clear() {
		size = 0;
	}

	/**
	 * Trims the underlying heap array so that it has exactly {@link #size()}
	 * elements.
	 */
	public void trim() {
		heap = CharArrays.trim(heap, size);
	}

	public CharComparator comparator() {
		return c;
	}

	private void writeObject(java.io.ObjectOutputStream s) throws java.io.IOException {
		s.defaultWriteObject();
		s.writeInt(heap.length);
		for (int i = 0; i < size; i++)
			s.writeChar(heap[i]);
	}

	private void readObject(java.io.ObjectInputStream s) throws java.io.IOException, ClassNotFoundException {
		s.defaultReadObject();
		heap = new char[s.readInt()];
		for (int i = 0; i < size; i++)
			heap[i] = s.readChar();
	}
}
