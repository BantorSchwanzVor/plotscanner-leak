/* Copyright (C) 1991-2016 Free Software Foundation, Inc.
   This file is part of the GNU C Library.

   The GNU C Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with the GNU C Library; if not, see
   <http://www.gnu.org/licenses/>.  */
/* This header is separate from features.h so that the compiler can
   include it implicitly at the start of every compilation.  It must
   not itself include <features.h> or any other header that includes
   <features.h> because the implicit include comes before any feature
   test macros that may be defined in a source file before it first
   explicitly includes a system header.  GCC knows the name of this
   header in order to preinclude it.  */
/* glibc's intent is to support the IEC 559 math functionality, real
   and complex.  If the GCC (4.9 and later) predefined macros
   specifying compiler intent are available, use them to determine
   whether the overall intent is to support these features; otherwise,
   presume an older compiler has intent to support these features and
   define these macros by default.  */
/* wchar_t uses Unicode 9.0.0.  Version 9.0 of the Unicode Standard is
   synchronized with ISO/IEC 10646:2014, fourth edition, plus
   Amd. 1  and Amd. 2 and 273 characters from forthcoming  10646, fifth edition.
   (Amd. 2 was published 2016-05-01,
   see https://www.iso.org/obp/ui/#iso:std:iso-iec:10646:ed-4:v1:amd:2:v1:en) */
/* We do not support C11 <threads.h>.  */
/* Generic definitions */
/* Assertions (useful to generate conditional code) */
/* Current type and class (and size, if applicable) */
/* Value methods */
/* Interfaces (keys) */
/* Interfaces (values) */
/* Abstract implementations (keys) */
/* Abstract implementations (values) */
/* Static containers (keys) */
/* Static containers (values) */
/* Implementations */
/* Synchronized wrappers */
/* Unmodifiable wrappers */
/* Other wrappers */
/* Methods (keys) */
/* Methods (values) */
/* Methods (keys/values) */
/* Methods that have special names depending on keys (but the special names depend on values) */
/* Equality */
/* Object/Reference-only definitions (keys) */
/* Primitive-type-only definitions (keys) */
/* Object/Reference-only definitions (values) */
/*		 
 * Copyright (C) 2003-2016 Paolo Boldi and Sebastiano Vigna
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License. 
 */
package it.unimi.dsi.fastutil.bytes;

import java.util.NoSuchElementException;

/**
 * A type-specific array-based priority queue.
 *
 * <P>
 * Instances of this class represent a priority queue using a backing
 * array&mdash;all operations are performed directly on the array. The array is
 * enlarged as needed, but it is never shrunk. Use the {@link #trim()} method to
 * reduce its size, if necessary.
 *
 * <P>
 * This implementation is extremely inefficient, but it is difficult to beat
 * when the size of the queue is very small.
 */
public class ByteArrayPriorityQueue extends AbstractBytePriorityQueue implements java.io.Serializable {
	private static final long serialVersionUID = 1L;
	/** The backing array. */

	protected transient byte array[] = ByteArrays.EMPTY_ARRAY;
	/** The number of elements in this queue. */
	protected int size;
	/** The type-specific comparator used in this queue. */
	protected ByteComparator c;
	/** The first index, cached, if {@link #firstIndexValid} is true. */
	transient protected int firstIndex;
	/** Whether {@link #firstIndex} contains a valid value. */
	transient protected boolean firstIndexValid;

	/**
	 * Creates a new empty queue with a given capacity and comparator.
	 *
	 * @param capacity
	 *            the initial capacity of this queue.
	 * @param c
	 *            the comparator used in this queue, or <code>null</code> for
	 *            the natural order.
	 */

	public ByteArrayPriorityQueue(int capacity, ByteComparator c) {
		if (capacity > 0) this.array = new byte[capacity];
		this.c = c;
	}

	/**
	 * Creates a new empty queue with a given capacity and using the natural
	 * order.
	 *
	 * @param capacity
	 *            the initial capacity of this queue.
	 */
	public ByteArrayPriorityQueue(int capacity) {
		this(capacity, null);
	}

	/**
	 * Creates a new empty queue with a given comparator.
	 *
	 * @param c
	 *            the comparator used in this queue, or <code>null</code> for
	 *            the natural order.
	 */
	public ByteArrayPriorityQueue(ByteComparator c) {
		this(0, c);
	}

	/**
	 * Creates a new empty queue using the natural order.
	 */
	public ByteArrayPriorityQueue() {
		this(0, null);
	}

	/**
	 * Wraps a given array in a queue using a given comparator.
	 *
	 * <P>
	 * The queue returned by this method will be backed by the given array.
	 *
	 * @param a
	 *            an array.
	 * @param size
	 *            the number of elements to be included in the queue.
	 * @param c
	 *            the comparator used in this queue, or <code>null</code> for
	 *            the natural order.
	 */
	public ByteArrayPriorityQueue(final byte[] a, int size, final ByteComparator c) {
		this(c);
		this.array = a;
		this.size = size;
	}

	/**
	 * Wraps a given array in a queue using a given comparator.
	 *
	 * <P>
	 * The queue returned by this method will be backed by the given array.
	 *
	 * @param a
	 *            an array.
	 * @param c
	 *            the comparator used in this queue, or <code>null</code> for
	 *            the natural order.
	 */
	public ByteArrayPriorityQueue(final byte[] a, final ByteComparator c) {
		this(a, a.length, c);
	}

	/**
	 * Wraps a given array in a queue using the natural order.
	 *
	 * <P>
	 * The queue returned by this method will be backed by the given array.
	 *
	 * @param a
	 *            an array.
	 * @param size
	 *            the number of elements to be included in the queue.
	 */
	public ByteArrayPriorityQueue(final byte[] a, int size) {
		this(a, size, null);
	}

	/**
	 * Wraps a given array in a queue using the natural order.
	 *
	 * <P>
	 * The queue returned by this method will be backed by the given array.
	 *
	 * @param a
	 *            an array.
	 */
	public ByteArrayPriorityQueue(final byte[] a) {
		this(a, a.length);
	}

	/** Returns the index of the smallest element. */

	private int findFirst() {
		if (firstIndexValid) return this.firstIndex;
		firstIndexValid = true;
		int i = size;
		int firstIndex = --i;
		byte first = array[firstIndex];
		if (c == null) {
			while (i-- != 0)
				if (((array[i]) < (first))) first = array[firstIndex = i];
		} else while (i-- != 0) {
			if (c.compare(array[i], first) < 0) first = array[firstIndex = i];
		}
		return this.firstIndex = firstIndex;
	}

	private void ensureNonEmpty() {
		if (size == 0) throw new NoSuchElementException();
	}

	public void enqueue(byte x) {
		if (size == array.length) array = ByteArrays.grow(array, size + 1);
		if (firstIndexValid) {
			if (c == null) {
				if (((x) < (array[firstIndex]))) firstIndex = size;
			} else if (c.compare(x, array[firstIndex]) < 0) firstIndex = size;
		} else firstIndexValid = false;
		array[size++] = x;
	}

	public byte dequeueByte() {
		ensureNonEmpty();
		final int first = findFirst();
		final byte result = array[first];
		System.arraycopy(array, first + 1, array, first, --size - first);
		firstIndexValid = false;
		return result;
	}

	public byte firstByte() {
		ensureNonEmpty();
		return array[findFirst()];
	}

	public void changed() {
		ensureNonEmpty();
		firstIndexValid = false;
	}

	public int size() {
		return size;
	}

	public void clear() {
		size = 0;
		firstIndexValid = false;
	}

	/**
	 * Trims the underlying array so that it has exactly {@link #size()}
	 * elements.
	 */
	public void trim() {
		array = ByteArrays.trim(array, size);
	}

	public ByteComparator comparator() {
		return c;
	}

	private void writeObject(java.io.ObjectOutputStream s) throws java.io.IOException {
		s.defaultWriteObject();
		s.writeInt(array.length);
		for (int i = 0; i < size; i++)
			s.writeByte(array[i]);
	}

	private void readObject(java.io.ObjectInputStream s) throws java.io.IOException, ClassNotFoundException {
		s.defaultReadObject();
		array = new byte[s.readInt()];
		for (int i = 0; i < size; i++)
			array[i] = s.readByte();
	}
}
