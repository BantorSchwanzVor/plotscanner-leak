package org.lwjgl.util.glu.tessellation;

class GLUhalfEdge {
  public GLUhalfEdge next;
  
  public GLUhalfEdge Sym;
  
  public GLUhalfEdge Onext;
  
  public GLUhalfEdge Lnext;
  
  public GLUvertex Org;
  
  public GLUface Lface;
  
  public ActiveRegion activeRegion;
  
  public int winding;
  
  public boolean first;
  
  GLUhalfEdge(boolean first) {
    this.first = first;
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl_util\2.9.4-nightly-20150209\lwjgl_util-2.9.4-nightly-20150209.jar!\org\lwjg\\util\glu\tessellation\GLUhalfEdge.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */