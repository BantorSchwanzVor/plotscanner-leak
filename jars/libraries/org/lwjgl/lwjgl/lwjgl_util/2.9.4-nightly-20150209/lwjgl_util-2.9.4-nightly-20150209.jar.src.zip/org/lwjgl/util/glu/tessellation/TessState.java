package org.lwjgl.util.glu.tessellation;

class TessState {
  public static final int T_DORMANT = 0;
  
  public static final int T_IN_POLYGON = 1;
  
  public static final int T_IN_CONTOUR = 2;
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl_util\2.9.4-nightly-20150209\lwjgl_util-2.9.4-nightly-20150209.jar!\org\lwjg\\util\glu\tessellation\TessState.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */