package org.lwjgl.util.glu.tessellation;

class CachedVertex {
  public double[] coords = new double[3];
  
  public Object data;
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl_util\2.9.4-nightly-20150209\lwjgl_util-2.9.4-nightly-20150209.jar!\org\lwjg\\util\glu\tessellation\CachedVertex.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */