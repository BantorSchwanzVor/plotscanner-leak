package org.lwjgl.util.glu;

import org.lwjgl.opengl.GL11;

class PixelStoreState extends Util {
  public int unpackRowLength;
  
  public int unpackAlignment;
  
  public int unpackSkipRows;
  
  public int unpackSkipPixels;
  
  public int packRowLength;
  
  public int packAlignment;
  
  public int packSkipRows;
  
  public int packSkipPixels;
  
  PixelStoreState() {
    load();
  }
  
  public void load() {
    this.unpackRowLength = glGetIntegerv(3314);
    this.unpackAlignment = glGetIntegerv(3317);
    this.unpackSkipRows = glGetIntegerv(3315);
    this.unpackSkipPixels = glGetIntegerv(3316);
    this.packRowLength = glGetIntegerv(3330);
    this.packAlignment = glGetIntegerv(3333);
    this.packSkipRows = glGetIntegerv(3331);
    this.packSkipPixels = glGetIntegerv(3332);
  }
  
  public void save() {
    GL11.glPixelStorei(3314, this.unpackRowLength);
    GL11.glPixelStorei(3317, this.unpackAlignment);
    GL11.glPixelStorei(3315, this.unpackSkipRows);
    GL11.glPixelStorei(3316, this.unpackSkipPixels);
    GL11.glPixelStorei(3330, this.packRowLength);
    GL11.glPixelStorei(3333, this.packAlignment);
    GL11.glPixelStorei(3331, this.packSkipRows);
    GL11.glPixelStorei(3332, this.packSkipPixels);
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl_util\2.9.4-nightly-20150209\lwjgl_util-2.9.4-nightly-20150209.jar!\org\lwjg\\util\glu\PixelStoreState.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */