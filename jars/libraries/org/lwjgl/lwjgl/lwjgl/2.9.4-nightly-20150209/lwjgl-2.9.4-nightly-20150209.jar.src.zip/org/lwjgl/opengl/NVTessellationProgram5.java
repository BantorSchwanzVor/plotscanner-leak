package org.lwjgl.opengl;

public final class NVTessellationProgram5 {
  public static final int GL_TESS_CONTROL_PROGRAM_NV = 35102;
  
  public static final int GL_TESS_EVALUATION_PROGRAM_NV = 35103;
  
  public static final int GL_TESS_CONTROL_PROGRAM_PARAMETER_BUFFER_NV = 35956;
  
  public static final int GL_TESS_EVALUATION_PROGRAM_PARAMETER_BUFFER_NV = 35957;
  
  public static final int GL_MAX_PROGRAM_PATCH_ATTRIBS_NV = 34520;
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opengl\NVTessellationProgram5.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */