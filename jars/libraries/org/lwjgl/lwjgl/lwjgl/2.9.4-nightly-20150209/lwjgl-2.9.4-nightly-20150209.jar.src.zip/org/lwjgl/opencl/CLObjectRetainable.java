package org.lwjgl.opencl;

abstract class CLObjectRetainable extends CLObject {
  private int refCount;
  
  protected CLObjectRetainable(long pointer) {
    super(pointer);
    if (super.isValid())
      this.refCount = 1; 
  }
  
  public final int getReferenceCount() {
    return this.refCount;
  }
  
  public final boolean isValid() {
    return (this.refCount > 0);
  }
  
  int retain() {
    checkValid();
    return ++this.refCount;
  }
  
  int release() {
    checkValid();
    return --this.refCount;
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opencl\CLObjectRetainable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */