package org.lwjgl.opengl;

public final class ATIMeminfo {
  public static final int GL_VBO_FREE_MEMORY_ATI = 34811;
  
  public static final int GL_TEXTURE_FREE_MEMORY_ATI = 34812;
  
  public static final int GL_RENDERBUFFER_FREE_MEMORY_ATI = 34813;
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opengl\ATIMeminfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */