package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.PointerBuffer;

public final class SharedDrawable extends DrawableGL {
  public SharedDrawable(Drawable drawable) throws LWJGLException {
    this.context = (ContextGL)((DrawableLWJGL)drawable).createSharedContext();
  }
  
  public ContextGL createSharedContext() {
    throw new UnsupportedOperationException();
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opengl\SharedDrawable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */