package org.lwjgl.opengl;

import java.nio.IntBuffer;
import org.lwjgl.PointerBuffer;

public final class ARBMultiBind {
  public static void glBindBuffersBase(int target, int first, int count, IntBuffer buffers) {
    GL44.glBindBuffersBase(target, first, count, buffers);
  }
  
  public static void glBindBuffersRange(int target, int first, int count, IntBuffer buffers, PointerBuffer offsets, PointerBuffer sizes) {
    GL44.glBindBuffersRange(target, first, count, buffers, offsets, sizes);
  }
  
  public static void glBindTextures(int first, int count, IntBuffer textures) {
    GL44.glBindTextures(first, count, textures);
  }
  
  public static void glBindSamplers(int first, int count, IntBuffer samplers) {
    GL44.glBindSamplers(first, count, samplers);
  }
  
  public static void glBindImageTextures(int first, int count, IntBuffer textures) {
    GL44.glBindImageTextures(first, count, textures);
  }
  
  public static void glBindVertexBuffers(int first, int count, IntBuffer buffers, PointerBuffer offsets, IntBuffer strides) {
    GL44.glBindVertexBuffers(first, count, buffers, offsets, strides);
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opengl\ARBMultiBind.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */