package org.lwjgl.opengl;

public final class ARBTextureRectangle {
  public static final int GL_TEXTURE_RECTANGLE_ARB = 34037;
  
  public static final int GL_TEXTURE_BINDING_RECTANGLE_ARB = 34038;
  
  public static final int GL_PROXY_TEXTURE_RECTANGLE_ARB = 34039;
  
  public static final int GL_MAX_RECTANGLE_TEXTURE_SIZE_ARB = 34040;
  
  public static final int GL_SAMPLER_2D_RECT_ARB = 35683;
  
  public static final int GL_SAMPLER_2D_RECT_SHADOW_ARB = 35684;
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opengl\ARBTextureRectangle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */