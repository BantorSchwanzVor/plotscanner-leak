package org.lwjgl.opengl;

public final class NVTextureShader2 {
  public static final int GL_DOT_PRODUCT_TEXTURE_3D_NV = 34543;
  
  public static final int GL_HILO_NV = 34548;
  
  public static final int GL_DSDT_NV = 34549;
  
  public static final int GL_DSDT_MAG_NV = 34550;
  
  public static final int GL_DSDT_MAG_VIB_NV = 34551;
  
  public static final int GL_UNSIGNED_INT_S8_S8_8_8_NV = 34522;
  
  public static final int GL_UNSIGNED_INT_8_8_S8_S8_REV_NV = 34523;
  
  public static final int GL_SIGNED_RGBA_NV = 34555;
  
  public static final int GL_SIGNED_RGBA8_NV = 34556;
  
  public static final int GL_SIGNED_RGB_NV = 34558;
  
  public static final int GL_SIGNED_RGB8_NV = 34559;
  
  public static final int GL_SIGNED_LUMINANCE_NV = 34561;
  
  public static final int GL_SIGNED_LUMINANCE8_NV = 34562;
  
  public static final int GL_SIGNED_LUMINANCE_ALPHA_NV = 34563;
  
  public static final int GL_SIGNED_LUMINANCE8_ALPHA8_NV = 34564;
  
  public static final int GL_SIGNED_ALPHA_NV = 34565;
  
  public static final int GL_SIGNED_ALPHA8_NV = 34566;
  
  public static final int GL_SIGNED_INTENSITY_NV = 34567;
  
  public static final int GL_SIGNED_INTENSITY8_NV = 34568;
  
  public static final int GL_SIGNED_RGB_UNSIGNED_ALPHA_NV = 34572;
  
  public static final int GL_SIGNED_RGB8_UNSIGNED_ALPHA8_NV = 34573;
  
  public static final int GL_HILO16_NV = 34552;
  
  public static final int GL_SIGNED_HILO_NV = 34553;
  
  public static final int GL_SIGNED_HILO16_NV = 34554;
  
  public static final int GL_DSDT8_NV = 34569;
  
  public static final int GL_DSDT8_MAG8_NV = 34570;
  
  public static final int GL_DSDT_MAG_INTENSITY_NV = 34524;
  
  public static final int GL_DSDT8_MAG8_INTENSITY8_NV = 34571;
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opengl\NVTextureShader2.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */