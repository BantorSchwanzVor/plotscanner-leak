package org.lwjgl.opencl;

import org.lwjgl.PointerWrapperAbstract;

abstract class CLObject extends PointerWrapperAbstract {
  protected CLObject(long pointer) {
    super(pointer);
  }
  
  final long getPointerUnsafe() {
    return this.pointer;
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opencl\CLObject.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */