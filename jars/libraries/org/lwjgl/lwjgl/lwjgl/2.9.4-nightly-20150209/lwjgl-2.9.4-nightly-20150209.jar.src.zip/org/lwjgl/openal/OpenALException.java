package org.lwjgl.openal;

public class OpenALException extends RuntimeException {
  private static final long serialVersionUID = 1L;
  
  public OpenALException() {}
  
  public OpenALException(int error_code) {
    super("OpenAL error: " + AL10.alGetString(error_code) + " (" + error_code + ")");
  }
  
  public OpenALException(String message) {
    super(message);
  }
  
  public OpenALException(String message, Throwable cause) {
    super(message, cause);
  }
  
  public OpenALException(Throwable cause) {
    super(cause);
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\openal\OpenALException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */