package org.lwjgl.opengl;

public final class ARBCompressedTexturePixelStorage {
  public static final int GL_UNPACK_COMPRESSED_BLOCK_WIDTH = 37159;
  
  public static final int GL_UNPACK_COMPRESSED_BLOCK_HEIGHT = 37160;
  
  public static final int GL_UNPACK_COMPRESSED_BLOCK_DEPTH = 37161;
  
  public static final int GL_UNPACK_COMPRESSED_BLOCK_SIZE = 37162;
  
  public static final int GL_PACK_COMPRESSED_BLOCK_WIDTH = 37163;
  
  public static final int GL_PACK_COMPRESSED_BLOCK_HEIGHT = 37164;
  
  public static final int GL_PACK_COMPRESSED_BLOCK_DEPTH = 37165;
  
  public static final int GL_PACK_COMPRESSED_BLOCK_SIZE = 37166;
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opengl\ARBCompressedTexturePixelStorage.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */