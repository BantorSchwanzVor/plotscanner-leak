package org.lwjgl.opengl;

public final class NVXGpuMemoryInfo {
  public static final int GL_GPU_MEMORY_INFO_DEDICATED_VIDMEM_NVX = 36935;
  
  public static final int GL_GPU_MEMORY_INFO_TOTAL_AVAILABLE_MEMORY_NVX = 36936;
  
  public static final int GL_GPU_MEMORY_INFO_CURRENT_AVAILABLE_VIDMEM_NVX = 36937;
  
  public static final int GL_GPU_MEMORY_INFO_EVICTION_COUNT_NVX = 36938;
  
  public static final int GL_GPU_MEMORY_INFO_EVICTED_MEMORY_NVX = 36939;
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opengl\NVXGpuMemoryInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */