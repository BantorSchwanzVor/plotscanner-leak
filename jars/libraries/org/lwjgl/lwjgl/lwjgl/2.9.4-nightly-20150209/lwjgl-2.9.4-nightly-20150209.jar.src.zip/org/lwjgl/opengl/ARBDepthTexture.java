package org.lwjgl.opengl;

public final class ARBDepthTexture {
  public static final int GL_DEPTH_COMPONENT16_ARB = 33189;
  
  public static final int GL_DEPTH_COMPONENT24_ARB = 33190;
  
  public static final int GL_DEPTH_COMPONENT32_ARB = 33191;
  
  public static final int GL_TEXTURE_DEPTH_SIZE_ARB = 34890;
  
  public static final int GL_DEPTH_TEXTURE_MODE_ARB = 34891;
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opengl\ARBDepthTexture.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */