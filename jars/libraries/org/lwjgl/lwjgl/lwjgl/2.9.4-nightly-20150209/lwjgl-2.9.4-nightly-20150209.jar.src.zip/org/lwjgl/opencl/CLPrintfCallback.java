package org.lwjgl.opencl;

import org.lwjgl.PointerWrapperAbstract;

public abstract class CLPrintfCallback extends PointerWrapperAbstract {
  protected CLPrintfCallback() {
    super(CallbackUtil.getPrintfCallback());
  }
  
  protected abstract void handleMessage(String paramString);
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opencl\CLPrintfCallback.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */