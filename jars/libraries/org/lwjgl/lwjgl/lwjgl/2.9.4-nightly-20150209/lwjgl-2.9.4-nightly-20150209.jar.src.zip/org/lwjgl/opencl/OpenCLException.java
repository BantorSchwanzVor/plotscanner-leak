package org.lwjgl.opencl;

public class OpenCLException extends RuntimeException {
  private static final long serialVersionUID = 1L;
  
  public OpenCLException() {}
  
  public OpenCLException(String message) {
    super(message);
  }
  
  public OpenCLException(String message, Throwable cause) {
    super(message, cause);
  }
  
  public OpenCLException(Throwable cause) {
    super(cause);
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opencl\OpenCLException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */