package org.lwjgl.opencl.api;

public final class CLImageFormat {
  public static final int STRUCT_SIZE = 8;
  
  private final int channelOrder;
  
  private final int channelType;
  
  public CLImageFormat(int channelOrder, int channelType) {
    this.channelOrder = channelOrder;
    this.channelType = channelType;
  }
  
  public int getChannelOrder() {
    return this.channelOrder;
  }
  
  public int getChannelType() {
    return this.channelType;
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opencl\api\CLImageFormat.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */