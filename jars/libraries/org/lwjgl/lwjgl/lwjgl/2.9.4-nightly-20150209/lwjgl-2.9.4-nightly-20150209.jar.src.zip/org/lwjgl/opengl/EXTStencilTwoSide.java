package org.lwjgl.opengl;

import org.lwjgl.BufferChecks;

public final class EXTStencilTwoSide {
  public static final int GL_STENCIL_TEST_TWO_SIDE_EXT = 35088;
  
  public static final int GL_ACTIVE_STENCIL_FACE_EXT = 35089;
  
  public static void glActiveStencilFaceEXT(int face) {
    ContextCapabilities caps = GLContext.getCapabilities();
    long function_pointer = caps.glActiveStencilFaceEXT;
    BufferChecks.checkFunctionAddress(function_pointer);
    nglActiveStencilFaceEXT(face, function_pointer);
  }
  
  static native void nglActiveStencilFaceEXT(int paramInt, long paramLong);
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opengl\EXTStencilTwoSide.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */