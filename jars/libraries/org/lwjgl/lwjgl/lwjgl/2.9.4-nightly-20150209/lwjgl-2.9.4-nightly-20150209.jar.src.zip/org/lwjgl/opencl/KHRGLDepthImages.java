package org.lwjgl.opencl;

public final class KHRGLDepthImages {
  public static final int CL_DEPTH_STENCIL = 4286;
  
  public static final int CL_UNORM_INT24 = 4319;
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opencl\KHRGLDepthImages.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */