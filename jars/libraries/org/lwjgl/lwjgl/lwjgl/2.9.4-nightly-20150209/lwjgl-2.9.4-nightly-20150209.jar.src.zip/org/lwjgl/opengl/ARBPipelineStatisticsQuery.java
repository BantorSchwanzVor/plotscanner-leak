package org.lwjgl.opengl;

public final class ARBPipelineStatisticsQuery {
  public static final int GL_VERTICES_SUBMITTED_ARB = 33518;
  
  public static final int GL_PRIMITIVES_SUBMITTED_ARB = 33519;
  
  public static final int GL_VERTEX_SHADER_INVOCATIONS_ARB = 33520;
  
  public static final int GL_TESS_CONTROL_SHADER_PATCHES_ARB = 33521;
  
  public static final int GL_TESS_EVALUATION_SHADER_INVOCATIONS_ARB = 33522;
  
  public static final int GL_GEOMETRY_SHADER_INVOCATIONS = 34943;
  
  public static final int GL_GEOMETRY_SHADER_PRIMITIVES_EMITTED_ARB = 33523;
  
  public static final int GL_FRAGMENT_SHADER_INVOCATIONS_ARB = 33524;
  
  public static final int GL_COMPUTE_SHADER_INVOCATIONS_ARB = 33525;
  
  public static final int GL_CLIPPING_INPUT_PRIMITIVES_ARB = 33526;
  
  public static final int GL_CLIPPING_OUTPUT_PRIMITIVES_ARB = 33527;
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opengl\ARBPipelineStatisticsQuery.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */