package org.lwjgl.opencl;

interface InfoUtil<T extends CLObject> {
  int getInfoInt(T paramT, int paramInt);
  
  long getInfoSize(T paramT, int paramInt);
  
  long[] getInfoSizeArray(T paramT, int paramInt);
  
  long getInfoLong(T paramT, int paramInt);
  
  String getInfoString(T paramT, int paramInt);
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opencl\InfoUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */