package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;

interface DrawableLWJGL extends Drawable {
  void setPixelFormat(PixelFormatLWJGL paramPixelFormatLWJGL) throws LWJGLException;
  
  void setPixelFormat(PixelFormatLWJGL paramPixelFormatLWJGL, ContextAttribs paramContextAttribs) throws LWJGLException;
  
  PixelFormatLWJGL getPixelFormat();
  
  Context getContext();
  
  Context createSharedContext() throws LWJGLException;
  
  void checkGLError();
  
  void setSwapInterval(int paramInt);
  
  void swapBuffers() throws LWJGLException;
  
  void initContext(float paramFloat1, float paramFloat2, float paramFloat3);
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opengl\DrawableLWJGL.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */