package org.lwjgl.opengl;

public final class ARBPointSprite {
  public static final int GL_POINT_SPRITE_ARB = 34913;
  
  public static final int GL_COORD_REPLACE_ARB = 34914;
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opengl\ARBPointSprite.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */