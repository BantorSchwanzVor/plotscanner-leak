package org.lwjgl.opencl;

import org.lwjgl.PointerWrapperAbstract;

abstract class CLProgramCallback extends PointerWrapperAbstract {
  private CLContext context;
  
  protected CLProgramCallback() {
    super(CallbackUtil.getProgramCallback());
  }
  
  final void setContext(CLContext context) {
    this.context = context;
  }
  
  private void handleMessage(long program_address) {
    handleMessage(this.context.getCLProgram(program_address));
  }
  
  protected abstract void handleMessage(CLProgram paramCLProgram);
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opencl\CLProgramCallback.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */