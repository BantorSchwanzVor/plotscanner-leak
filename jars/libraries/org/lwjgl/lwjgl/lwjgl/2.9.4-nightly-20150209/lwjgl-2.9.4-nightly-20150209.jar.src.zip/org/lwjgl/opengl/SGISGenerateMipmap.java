package org.lwjgl.opengl;

public final class SGISGenerateMipmap {
  public static final int GL_GENERATE_MIPMAP_SGIS = 33169;
  
  public static final int GL_GENERATE_MIPMAP_HINT_SGIS = 33170;
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opengl\SGISGenerateMipmap.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */