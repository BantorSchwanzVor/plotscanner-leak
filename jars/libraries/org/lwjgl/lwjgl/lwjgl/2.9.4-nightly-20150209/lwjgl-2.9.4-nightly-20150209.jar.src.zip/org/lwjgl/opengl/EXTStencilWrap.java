package org.lwjgl.opengl;

public final class EXTStencilWrap {
  public static final int GL_INCR_WRAP_EXT = 34055;
  
  public static final int GL_DECR_WRAP_EXT = 34056;
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opengl\EXTStencilWrap.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */