package org.lwjgl.opencl.api;

import org.lwjgl.PointerBuffer;

public final class CLBufferRegion {
  public static final int STRUCT_SIZE = 2 * PointerBuffer.getPointerSize();
  
  private final int origin;
  
  private final int size;
  
  public CLBufferRegion(int origin, int size) {
    this.origin = origin;
    this.size = size;
  }
  
  public int getOrigin() {
    return this.origin;
  }
  
  public int getSize() {
    return this.size;
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opencl\api\CLBufferRegion.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */