package org.lwjgl.opengl;

public final class ARBPixelBufferObject extends ARBBufferObject {
  public static final int GL_PIXEL_PACK_BUFFER_ARB = 35051;
  
  public static final int GL_PIXEL_UNPACK_BUFFER_ARB = 35052;
  
  public static final int GL_PIXEL_PACK_BUFFER_BINDING_ARB = 35053;
  
  public static final int GL_PIXEL_UNPACK_BUFFER_BINDING_ARB = 35055;
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opengl\ARBPixelBufferObject.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */