package org.lwjgl.opencl;

import org.lwjgl.LWJGLUtil;

abstract class CLObjectChild<P extends CLObject> extends CLObjectRetainable {
  private final P parent;
  
  protected CLObjectChild(long pointer, P parent) {
    super(pointer);
    if (LWJGLUtil.DEBUG && parent != null && !parent.isValid())
      throw new IllegalStateException("The parent specified is not a valid CL object."); 
    this.parent = parent;
  }
  
  public P getParent() {
    return this.parent;
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opencl\CLObjectChild.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */