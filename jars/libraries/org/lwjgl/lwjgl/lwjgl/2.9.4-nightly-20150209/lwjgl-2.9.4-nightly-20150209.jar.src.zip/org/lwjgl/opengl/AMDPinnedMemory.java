package org.lwjgl.opengl;

public final class AMDPinnedMemory {
  public static final int GL_EXTERNAL_VIRTUAL_MEMORY_BUFFER_AMD = 37216;
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opengl\AMDPinnedMemory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */