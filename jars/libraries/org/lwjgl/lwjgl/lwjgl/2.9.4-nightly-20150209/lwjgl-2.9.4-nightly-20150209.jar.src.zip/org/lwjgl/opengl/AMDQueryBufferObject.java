package org.lwjgl.opengl;

public final class AMDQueryBufferObject {
  public static final int GL_QUERY_RESULT_NO_WAIT_AMD = 37268;
  
  public static final int GL_QUERY_BUFFER_AMD = 37266;
  
  public static final int GL_QUERY_BUFFER_BINDING_AMD = 37267;
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opengl\AMDQueryBufferObject.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */