package org.lwjgl.opengl;

public final class NVFragmentProgram2 {
  public static final int GL_MAX_PROGRAM_EXEC_INSTRUCTIONS_NV = 35060;
  
  public static final int GL_MAX_PROGRAM_CALL_DEPTH_NV = 35061;
  
  public static final int GL_MAX_PROGRAM_IF_DEPTH_NV = 35062;
  
  public static final int GL_MAX_PROGRAM_LOOP_DEPTH_NV = 35063;
  
  public static final int GL_MAX_PROGRAM_LOOP_COUNT_NV = 35064;
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opengl\NVFragmentProgram2.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */