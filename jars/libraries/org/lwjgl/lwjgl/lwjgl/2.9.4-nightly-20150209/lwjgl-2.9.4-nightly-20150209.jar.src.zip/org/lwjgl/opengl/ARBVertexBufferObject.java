package org.lwjgl.opengl;

public final class ARBVertexBufferObject extends ARBBufferObject {
  public static final int GL_ARRAY_BUFFER_ARB = 34962;
  
  public static final int GL_ELEMENT_ARRAY_BUFFER_ARB = 34963;
  
  public static final int GL_ARRAY_BUFFER_BINDING_ARB = 34964;
  
  public static final int GL_ELEMENT_ARRAY_BUFFER_BINDING_ARB = 34965;
  
  public static final int GL_VERTEX_ARRAY_BUFFER_BINDING_ARB = 34966;
  
  public static final int GL_NORMAL_ARRAY_BUFFER_BINDING_ARB = 34967;
  
  public static final int GL_COLOR_ARRAY_BUFFER_BINDING_ARB = 34968;
  
  public static final int GL_INDEX_ARRAY_BUFFER_BINDING_ARB = 34969;
  
  public static final int GL_TEXTURE_COORD_ARRAY_BUFFER_BINDING_ARB = 34970;
  
  public static final int GL_EDGE_FLAG_ARRAY_BUFFER_BINDING_ARB = 34971;
  
  public static final int GL_SECONDARY_COLOR_ARRAY_BUFFER_BINDING_ARB = 34972;
  
  public static final int GL_FOG_COORDINATE_ARRAY_BUFFER_BINDING_ARB = 34973;
  
  public static final int GL_WEIGHT_ARRAY_BUFFER_BINDING_ARB = 34974;
  
  public static final int GL_VERTEX_ATTRIB_ARRAY_BUFFER_BINDING_ARB = 34975;
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opengl\ARBVertexBufferObject.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */