package org.lwjgl.opengl;

public final class NVTextureRectangle {
  public static final int GL_TEXTURE_RECTANGLE_NV = 34037;
  
  public static final int GL_TEXTURE_BINDING_RECTANGLE_NV = 34038;
  
  public static final int GL_PROXY_TEXTURE_RECTANGLE_NV = 34039;
  
  public static final int GL_MAX_RECTANGLE_TEXTURE_SIZE_NV = 34040;
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opengl\NVTextureRectangle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */