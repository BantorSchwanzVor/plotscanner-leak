package org.lwjgl.opencl;

import java.nio.ByteBuffer;
import org.lwjgl.PointerWrapperAbstract;

public abstract class CLNativeKernel extends PointerWrapperAbstract {
  protected CLNativeKernel() {
    super(CallbackUtil.getNativeKernelCallback());
  }
  
  protected abstract void execute(ByteBuffer[] paramArrayOfByteBuffer);
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opencl\CLNativeKernel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */