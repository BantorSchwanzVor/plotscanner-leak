package org.lwjgl.opengl;

public final class EXTFramebufferSRGB {
  public static final int GLX_FRAMEBUFFER_SRGB_CAPABLE_EXT = 8370;
  
  public static final int WGL_FRAMEBUFFER_SRGB_CAPABLE_EXT = 8361;
  
  public static final int GL_FRAMEBUFFER_SRGB_EXT = 36281;
  
  public static final int GL_FRAMEBUFFER_SRGB_CAPABLE_EXT = 36282;
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opengl\EXTFramebufferSRGB.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */