package org.lwjgl.opengl;

public final class ATITextureFloat {
  public static final int GL_RGBA_FLOAT32_ATI = 34836;
  
  public static final int GL_RGB_FLOAT32_ATI = 34837;
  
  public static final int GL_ALPHA_FLOAT32_ATI = 34838;
  
  public static final int GL_INTENSITY_FLOAT32_ATI = 34839;
  
  public static final int GL_LUMINANCE_FLOAT32_ATI = 34840;
  
  public static final int GL_LUMINANCE_ALPHA_FLOAT32_ATI = 34841;
  
  public static final int GL_RGBA_FLOAT16_ATI = 34842;
  
  public static final int GL_RGB_FLOAT16_ATI = 34843;
  
  public static final int GL_ALPHA_FLOAT16_ATI = 34844;
  
  public static final int GL_INTENSITY_FLOAT16_ATI = 34845;
  
  public static final int GL_LUMINANCE_FLOAT16_ATI = 34846;
  
  public static final int GL_LUMINANCE_ALPHA_FLOAT16_ATI = 34847;
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opengl\ATITextureFloat.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */