package org.lwjgl.opengl;

import java.awt.Canvas;
import java.awt.Graphics;

final class MacOSXGLCanvas extends Canvas {
  private static final long serialVersionUID = 6916664741667434870L;
  
  private boolean canvas_painted;
  
  private boolean dirty;
  
  public void update(Graphics g) {
    paint(g);
  }
  
  public void paint(Graphics g) {
    synchronized (this) {
      this.dirty = true;
      this.canvas_painted = true;
    } 
  }
  
  public boolean syncCanvasPainted() {
    boolean result;
    synchronized (this) {
      result = this.canvas_painted;
      this.canvas_painted = false;
    } 
    return result;
  }
  
  public boolean syncIsDirty() {
    boolean result;
    synchronized (this) {
      result = this.dirty;
      this.dirty = false;
    } 
    return result;
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opengl\MacOSXGLCanvas.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */