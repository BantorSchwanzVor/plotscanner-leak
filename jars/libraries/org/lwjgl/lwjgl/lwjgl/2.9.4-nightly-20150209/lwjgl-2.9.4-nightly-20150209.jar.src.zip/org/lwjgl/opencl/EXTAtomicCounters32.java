package org.lwjgl.opencl;

public final class EXTAtomicCounters32 {
  public static final int CL_DEVICE_MAX_ATOMIC_COUNTERS_EXT = 16434;
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opencl\EXTAtomicCounters32.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */