package org.lwjgl.opengl;

import java.nio.IntBuffer;

public final class ARBInternalformatQuery {
  public static final int GL_NUM_SAMPLE_COUNTS = 37760;
  
  public static void glGetInternalformat(int target, int internalformat, int pname, IntBuffer params) {
    GL42.glGetInternalformat(target, internalformat, pname, params);
  }
  
  public static int glGetInternalformat(int target, int internalformat, int pname) {
    return GL42.glGetInternalformat(target, internalformat, pname);
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opengl\ARBInternalformatQuery.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */