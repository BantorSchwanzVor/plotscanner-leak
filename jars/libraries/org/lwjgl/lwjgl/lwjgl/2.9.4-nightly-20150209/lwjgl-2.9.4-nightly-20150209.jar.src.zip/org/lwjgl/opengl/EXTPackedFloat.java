package org.lwjgl.opengl;

public final class EXTPackedFloat {
  public static final int GL_R11F_G11F_B10F_EXT = 35898;
  
  public static final int GL_UNSIGNED_INT_10F_11F_11F_REV_EXT = 35899;
  
  public static final int GL_RGBA_SIGNED_COMPONENTS_EXT = 35900;
  
  public static final int WGL_TYPE_RGBA_UNSIGNED_FLOAT_EXT = 8360;
  
  public static final int GLX_RGBA_UNSIGNED_FLOAT_TYPE_EXT = 8369;
  
  public static final int GLX_RGBA_UNSIGNED_FLOAT_BIT_EXT = 8;
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opengl\EXTPackedFloat.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */