package org.lwjgl.opengl;

public final class HPOcclusionTest {
  public static final int GL_OCCLUSION_TEST_HP = 33125;
  
  public static final int GL_OCCLUSION_TEST_RESULT_HP = 33126;
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opengl\HPOcclusionTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */