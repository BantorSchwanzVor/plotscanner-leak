package org.lwjgl.openal;

public final class Util {
  public static void checkALCError(ALCdevice device) {
    int err = ALC10.alcGetError(device);
    if (err != 0)
      throw new OpenALException(ALC10.alcGetString(AL.getDevice(), err)); 
  }
  
  public static void checkALError() {
    int err = AL10.alGetError();
    if (err != 0)
      throw new OpenALException(err); 
  }
  
  public static void checkALCValidDevice(ALCdevice device) {
    if (!device.isValid())
      throw new OpenALException("Invalid device: " + device); 
  }
  
  public static void checkALCValidContext(ALCcontext context) {
    if (!context.isValid())
      throw new OpenALException("Invalid context: " + context); 
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\openal\Util.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */