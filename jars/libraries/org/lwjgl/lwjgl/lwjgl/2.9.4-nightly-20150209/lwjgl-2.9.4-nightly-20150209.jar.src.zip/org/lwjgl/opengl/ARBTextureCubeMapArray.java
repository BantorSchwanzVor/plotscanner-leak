package org.lwjgl.opengl;

public final class ARBTextureCubeMapArray {
  public static final int GL_TEXTURE_CUBE_MAP_ARRAY_ARB = 36873;
  
  public static final int GL_TEXTURE_BINDING_CUBE_MAP_ARRAY_ARB = 36874;
  
  public static final int GL_PROXY_TEXTURE_CUBE_MAP_ARRAY_ARB = 36875;
  
  public static final int GL_SAMPLER_CUBE_MAP_ARRAY_ARB = 36876;
  
  public static final int GL_SAMPLER_CUBE_MAP_ARRAY_SHADOW_ARB = 36877;
  
  public static final int GL_INT_SAMPLER_CUBE_MAP_ARRAY_ARB = 36878;
  
  public static final int GL_UNSIGNED_INT_SAMPLER_CUBE_MAP_ARRAY_ARB = 36879;
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opengl\ARBTextureCubeMapArray.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */