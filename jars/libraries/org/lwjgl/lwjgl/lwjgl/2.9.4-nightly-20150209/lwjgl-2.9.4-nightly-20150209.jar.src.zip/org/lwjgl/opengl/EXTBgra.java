package org.lwjgl.opengl;

public final class EXTBgra {
  public static final int GL_BGR_EXT = 32992;
  
  public static final int GL_BGRA_EXT = 32993;
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opengl\EXTBgra.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */