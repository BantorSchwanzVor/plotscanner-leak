package org.lwjgl.opengl;

import java.nio.IntBuffer;

public final class ARBVertexArrayObject {
  public static final int GL_VERTEX_ARRAY_BINDING = 34229;
  
  public static void glBindVertexArray(int array) {
    GL30.glBindVertexArray(array);
  }
  
  public static void glDeleteVertexArrays(IntBuffer arrays) {
    GL30.glDeleteVertexArrays(arrays);
  }
  
  public static void glDeleteVertexArrays(int array) {
    GL30.glDeleteVertexArrays(array);
  }
  
  public static void glGenVertexArrays(IntBuffer arrays) {
    GL30.glGenVertexArrays(arrays);
  }
  
  public static int glGenVertexArrays() {
    return GL30.glGenVertexArrays();
  }
  
  public static boolean glIsVertexArray(int array) {
    return GL30.glIsVertexArray(array);
  }
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\org\lwjgl\lwjgl\lwjgl\2.9.4-nightly-20150209\lwjgl-2.9.4-nightly-20150209.jar!\org\lwjgl\opengl\ARBVertexArrayObject.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */