package oshi.software.os;

public interface OperatingSystem {
  String getFamily();
  
  String getManufacturer();
  
  OperatingSystemVersion getVersion();
}


/* Location:              C:\Users\BSV\AppData\Local\Temp\Rar$DRa6216.20396\Preview\Preview.jar!\jars\libraries\oshi-project\oshi-core\1.1\oshi-core-1.1.jar!\oshi\software\os\OperatingSystem.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */